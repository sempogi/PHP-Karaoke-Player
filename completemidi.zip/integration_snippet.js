
// === Integration snippet ===
// 1) After Audio/Channels ready:
AutoTune285.init({ audioCtx, channels });

// 2) After parsing the MIDI and collecting events:
AutoTune285.autoTuneTo285FromKeySignature(playState.evs || []);

// 3) In createMelodicVoice() frequency calculation:
// var baseFreq = midiToFreq(note);
// var centsTotal = AutoTune285.globalDetuneCents + (channels[ch].detuneCents || 0) + (channels[ch].bend * 100);
// var freq = baseFreq * centsToRatio(centsTotal);
// voice.baseFreq = baseFreq; // ensure base stored

// 4) If you change tuning later, retune live:
// AutoTune285.retuneAllActiveVoices();

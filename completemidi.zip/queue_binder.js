(function(){
  function decodeB64(s){
    try { return atob(s || ''); } catch(e){ return ''; }
  }
  function bindQueueClicks(){
    var root = document.getElementById('playlist');
    if (!root || root.__queueBound) return;
    root.__queueBound = true;

    root.addEventListener('click', function(e){
      var link = e.target.closest('a.song');
      if (!link || !root.contains(link)) return;
      e.preventDefault();
      e.stopPropagation();
      var rel   = link.getAttribute('data-path');
      var rootB = link.getAttribute('data-root');
      var base  = decodeB64(rootB);   // canonical base at queue time
      var name  = (link.textContent||'').trim();
      var path  = link.getAttribute('title') || rel;
      if (!rel) return;
      var item = { rel: rel, name: name || rel, path: path || rel, base: base };
      if (typeof window.queueSong === 'function') {
        window.queueSong(rel, item);  // keep your signature; item carries base
      } else {
        document.dispatchEvent(new CustomEvent('enqueueSong', { detail: item }));
      }
    });
  }
  document.addEventListener('DOMContentLoaded', bindQueueClicks);
  document.addEventListener('browserListRefreshed', bindQueueClicks);
})();

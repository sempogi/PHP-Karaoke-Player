/* FireworksBG Panel — adds a small control panel to enable/disable the fireworksBG canvas
 * Usage:
 *   1) Include fireworks_bg.js (the engine) OR let this panel auto-load it.
 *   2) Include this file, then call: FWBGPanel.init({ mount: '#controlCenter' });
 *      - If mount not found, it will dock bottom-right of the window.
 * Notes:
 *   - Panel starts collapsed; only opens by toggle.
 *   - Persists settings in localStorage under key 'fwbg_panel_v1'.
 */
(function(){
  'use strict';
  const LS_KEY = 'fwbg_panel_v1';
  const DEFAULTS = {
    enabled:false, density:0.65, wind:0.08, brightness:0.92, opacity:0.92, bloom:1.9,
    crackle:true, strobe:true, palm:true, crossette:true,
    collapsed:true,
    zIndex: 1,                // ↓ keep fireworks well behind overlays
    badgeHidden: true         // ↓ hide floating badge by default
  };

  function loadState(){
    try{
      const s = JSON.parse(localStorage.getItem(LS_KEY)||'{}');
      return Object.assign({}, DEFAULTS, s);
    }catch(_){
      return Object.assign({}, DEFAULTS);
    }
  }
  function saveState(s){
    try{ localStorage.setItem(LS_KEY, JSON.stringify(s)); }catch(_){ }
  }

  function ensureEngine(src){
    return new Promise((resolve,reject)=>{
      if(window.fireworksBG){ resolve(); return; }
      const el = document.createElement('script');
      el.src = src || 'fireworks_bg.js';
      el.async = true;
      el.onload = () => resolve();
      el.onerror = () => reject(new Error('Failed to load fireworks_bg.js'));
      document.head.appendChild(el);
    });
  }

  function h(tag, attrs, ...children){
    const el = document.createElement(tag);
    if(attrs){
      for(const k in attrs){
        if(k==='style' && typeof attrs[k]==='object'){
          Object.assign(el.style, attrs[k]);
        } else if(k.startsWith('on') && typeof attrs[k]==='function'){
          el.addEventListener(k.substring(2), attrs[k]);
        } else if(k==='html'){
          el.innerHTML = attrs[k];
        } else {
          el.setAttribute(k, attrs[k]);
        }
      }
    }
    children.flat().forEach(c=>{
      if(c==null) return;
      if(typeof c==='string') el.appendChild(document.createTextNode(c));
      else el.appendChild(c);
    });
    return el;
  }

  function buildPanel(state){
    const css = `
      .fwbg-panel{ font:12px/1.3 system-ui,Segoe UI,Arial,sans-serif; color:#eee; background:rgba(0,0,0,.55); border:1px solid rgba(255,255,255,.08); border-radius:10px; padding:8px 10px; display:flex; flex-direction:column; gap:8px; backdrop-filter:saturate(120%) blur(3px); box-shadow:0 6px 16px rgba(0,0,0,.35); }
      .fwbg-row{ display:flex; align-items:center; gap:8px; flex-wrap:wrap }
      .fwbg-row label{ display:flex; align-items:center; gap:6px; white-space:nowrap }
      .fwbg-row input[type="range"]{ width:140px }
      .fwbg-badge{ position:relative; display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:5px 8px; background:rgba(0,0,0,.55); color:#ffd54f; font:12px system-ui; cursor:pointer; }
      .fwbg-dock{ position:fixed; right:12px; bottom:12px; z-index:9999; display:flex; flex-direction:column; gap:8px; align-items:flex-end }
      .fwbg-mini{ cursor:pointer; user-select:none }
      .fwbg-hidden{ display:none }
      .fwbg-hr{ height:1px; background:linear-gradient(90deg, transparent, rgba(255,255,255,.15), transparent) }
    `;
    const style = h('style',{html:css});

    const badge = h('div',{class:'fwbg-badge fwbg-mini', title:'Fireworks Background'},
      '🎆 Fireworks', h('span',{style:{opacity:.8}}, '(tap to open)')
    );
    if (state.badgeHidden) badge.style.display = 'none'; // ← hide badge by default

    // Inputs
    const chkOn   = h('input',{type:'checkbox'}); chkOn.checked = !!state.enabled;
    const rngDen  = h('input',{type:'range', min:'0', max:'1', step:'0.01', value:String(state.density)});
    const rngWind = h('input',{type:'range', min:'-0.6', max:'0.6', step:'0.01', value:String(state.wind)});
    const rngBrt  = h('input',{type:'range', min:'0.6', max:'1.2', step:'0.01', value:String(state.brightness)});
    const rngOp   = h('input',{type:'range', min:'0.6', max:'1.0', step:'0.01', value:String(state.opacity)});
    const chkCrk  = h('input',{type:'checkbox'}); chkCrk.checked = !!state.crackle;
    const chkStrb = h('input',{type:'checkbox'}); chkStrb.checked = !!state.strobe;
    const chkPalm = h('input',{type:'checkbox'}); chkPalm.checked = !!state.palm;
    const chkXset = h('input',{type:'checkbox'}); chkXset.checked = !!state.crossette;

    const btnApply = h('button', {type:'button', style:{padding:'6px 10px', borderRadius:'8px', border:'1px solid rgba(255,255,255,.2)', background:'#111', color:'#fff', cursor:'pointer'}}, 'Apply');
    const btnClose = h('button', {type:'button', style:{padding:'4px 8px', borderRadius:'8px', border:'1px solid rgba(255,255,255,.2)', background:'#111', color:'#fff', cursor:'pointer'}}, 'Close');

    const panel = h('div',{class:'fwbg-panel '+(state.collapsed?'fwbg-hidden':''), style:{minWidth:'320px'}},
      h('div',{class:'fwbg-row'}, h('label',null, chkOn, ' Enable Fireworks')),
      h('div',{class:'fwbg-row'}, h('label',null, 'Density', rngDen), h('label',null, 'Wind', rngWind)),
      h('div',{class:'fwbg-row'}, h('label',null, 'Brightness', rngBrt), h('label',null, 'Opacity', rngOp)),
      h('div',{class:'fwbg-row'}, h('label',null, chkCrk, 'Crackle'), h('label',null, chkStrb, 'Strobe'), h('label',null, chkPalm, 'Palm'), h('label',null, chkXset, 'Crossette')),
      h('div',{class:'fwbg-hr'}),
      h('div',{class:'fwbg-row'}, btnApply, btnClose)
    );

    const wrap = h('div',{class:'fwbg-dock'}, style, badge, panel);

    // Events
    badge.addEventListener('click', ()=>{
      panel.classList.toggle('fwbg-hidden');
      state.collapsed = panel.classList.contains('fwbg-hidden');
      saveState(state);
    });
    btnClose.addEventListener('click', ()=>{
      panel.classList.add('fwbg-hidden');
      state.collapsed = true;
      saveState(state);
    });

    btnApply.addEventListener('click', async ()=>{
      Object.assign(state, {
        enabled: !!chkOn.checked,
        density: parseFloat(rngDen.value),
        wind: parseFloat(rngWind.value),
        brightness: parseFloat(rngBrt.value),
        opacity: parseFloat(rngOp.value),
        crackle: chkCrk.checked, strobe: chkStrb.checked, palm: chkPalm.checked, crossette: chkXset.checked
      });
      saveState(state);
      try{
        await ensureEngine();
        if(state.enabled){
          fireworksBG.start({
            density: state.density, wind: state.wind, brightness: state.brightness, bloom: state.bloom,
            crackle: state.crackle, strobe: state.strobe, palm: state.palm, crossette: state.crossette
          });
          fireworksBG.setZ(state.zIndex || 1);       // ← push bg behind overlays
          fireworksBG.setOpacity(state.opacity);
          document.getElementById('fireworks-bgfx')?.classList.remove('fwbg-off'); // in case CSS off-class is used
        } else {
          // Prefer full removal (if engine supports destroy), else stop + hide via CSS class.
          if (fireworksBG.destroy) { fireworksBG.destroy(); }
          else {
            fireworksBG.stop();
            document.getElementById('fireworks-bgfx')?.classList.add('fwbg-off');
          }
        }
      }catch(err){
        alert('Fireworks engine not available: ' + err.message);
      }
    });

    return {wrap, panel, badge, state};
  }

  const FWBGPanel = {
    init(opts){
      const state = loadState();
      const {wrap, panel} = buildPanel(state);
      let mounted = false;
      if(opts && opts.mount){
        const host = document.querySelector(opts.mount);
        if(host){ host.appendChild(wrap); mounted = true; }
      }
      if(!mounted){ document.body.appendChild(wrap); }

      // Auto-restore without auto-opening panel
      if(state.enabled){
        ensureEngine().then(()=>{
          fireworksBG.start({
            density: state.density, wind: state.wind, brightness: state.brightness, bloom: state.bloom,
            crackle: state.crackle, strobe: state.strobe, palm: state.palm, crossette: state.crossette
          });
          fireworksBG.setZ(state.zIndex || 1);      // ← keep low z
          fireworksBG.setOpacity(state.opacity);
        }).catch(()=>{});
      }
    }
  };

  window.FWBGPanel = FWBGPanel;
})();
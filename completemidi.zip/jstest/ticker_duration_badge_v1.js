/*! Ticker Duration Badge v1.0.0 — Sem • 2025-10-16
 * Scope: Ticker only (non-invasive add-on)
 * Goal : Show duration as a small badge (⏱ mm:ss or h:mm:ss) in the ticker metadata area.
 * Load : AFTER your current scripts (incl. no_duration_title_hotfix_v1.js if used).
 */
(function(window, document){
  'use strict';
  if (window.__TICKER_DUR_BADGE__) return; window.__TICKER_DUR_BADGE__='v1.0.0';

  // Toggle: localStorage['tickerDurationBadge']='off' to disable
  function enabled(){ try{ return (localStorage.getItem('tickerDurationBadge')||'on')==='on'; }catch(_){ return true; } }

  // Minimal styles
  (function ensureStyle(){
    if (document.getElementById('tickerDurBadgeCSS')) return;
    var st=document.createElement('style'); st.id='tickerDurBadgeCSS';
    st.textContent = [
      '.ticker-badges{display:inline-flex;gap:6px;align-items:center;margin-left:8px}',
      '.ticker-badge{display:inline-flex;align-items:center;gap:.35em;padding:.2em .55em;border-radius:999px;background:rgba(255,255,255,.88);color:#20242b;font-weight:700;font-size:.82em}',
      '.ticker-badge .ico{font-size:1.05em}',
      '#tickerDurBadge{white-space:nowrap}',
    ].join('\n');
    document.head.appendChild(st);
  })();

  // Find where to place badges
  var CANDIDATES = [
    '#tickerInfo .meta',
    '#tickerInfo .extras',
    '#tickerInfo',
    '.ticker .meta',
    '.ticker .extras',
    '.ticker'
  ];

  function $(sel){ return document.querySelector(sel); }
  function placeBadgeContainer(){
    var host=null;
    for (var i=0;i<CANDIDATES.length;i++){ var h=$(CANDIDATES[i]); if (h){ host=h; break; } }
    if (!host) return null;
    var wrap=host.querySelector('.ticker-badges');
    if (!wrap){ wrap=document.createElement('span'); wrap.className='ticker-badges'; host.appendChild(wrap); }
    return wrap;
  }

  function getBadgeEl(){ var el=document.getElementById('tickerDurBadge'); if (el) return el; var wrap=placeBadgeContainer(); if (!wrap) return null; el=document.createElement('span'); el.id='tickerDurBadge'; el.className='ticker-badge'; el.innerHTML='<span class="ico" aria-hidden="true">⏱</span><span class="txt">00:00</span>'; wrap.appendChild(el); return el; }

  function formatDuration(sec){ try{ sec=Math.max(0, Math.floor(sec||0)); var h=Math.floor(sec/3600), m=Math.floor((sec%3600)/60), s=sec%60; var mm=(h?String(m).padStart(2,'0'):String(m)); var ss=String(s).padStart(2,'0'); return h ? (h+':'+mm+':'+ss) : (mm+':'+ss); }catch(_){ return '00:00'; } }

  // Extract duration from arguments or globals
  var D_RX=/\b(?:([0-9]?):)?([0-5]?\d):([0-5]\d)\b/; // h?:mm:ss or m:ss
  function extractFromTitle(title){ try{ var s=String(title||''); var m=s.match(D_RX); if (!m) return null; var h=parseInt(m[1]||'0',10)||0, m2=parseInt(m[2]||'0',10)||0, s2=parseInt(m[3]||'0',10)||0; return h*3600+m2*60+s2; }catch(_){ return null; } }

  function resolveDurationSec(){
    try{ if (typeof window.songDurationSec==='number') return Math.floor(window.songDurationSec); }catch(_){}
    try{ if (typeof window.songDurationMs==='number') return Math.floor(window.songDurationMs/1000); }catch(_){}
    try{ if (typeof window.totalMs==='number') return Math.floor(window.totalMs/1000); }catch(_){}
    // Try MIDIFile if present and lastMIDIBuf known
    try{
      var ab=window.lastMIDIBuf; if (ab && ab.byteLength && typeof MIDIFile==='function'){
        var mf=new MIDIFile(ab); var evs=(mf.getMidiEvents? mf.getMidiEvents(): mf.getEvents()); var max=0; for (var i=0;i<evs.length;i++){ var e=evs[i]||{}; var pt=(e.playTime!=null? e.playTime: e.playtime!=null? e.playtime: null); if (pt!=null) { var s=Math.floor(pt/1000); if (s>max) max=s; } } return max||null;
      }
    }catch(_){}
    return null;
  }

  function updateBadge(sec){ if (!enabled()) return; var el=getBadgeEl(); if (!el) return; var txt=el.querySelector('.txt'); if (!txt) return; txt.textContent = formatDuration(sec!=null?sec:0); el.style.display='inline-flex'; }

  // Hook ticker functions to refresh duration badge
  (function hookTicker(){
    function wrap(name){ var fn=window[name]; if (typeof fn!=='function' || fn.__durBadge) return; window[name] = function(){
      try{
        var a=[].slice.call(arguments), sec=null;
        if (a.length){
          if (typeof a[0]==='string') sec = extractFromTitle(a[0]);
          else if (a[0] && typeof a[0]==='object' && a[0].title) sec = extractFromTitle(a[0].title);
        }
        var r=fn.apply(this, arguments);
        if (sec==null) sec = resolveDurationSec();
        if (sec!=null) updateBadge(sec);
        return r;
      }catch(_){ return fn.apply(this, arguments); }
    }; window[name].__durBadge=1; }
    wrap('updateTicker');
    wrap('setNowPlaying');
  })();

  // Repaint badge on status changes if StatusBus exists
  (function bus(){ if (!window.StatusBus || typeof StatusBus.on!=='function') return; StatusBus.on(function(e){ try{ var msg=String(e.msg||''); if (msg==='PLAYING'){ var sec=resolveDurationSec(); if (sec!=null) updateBadge(sec); } }catch(_){} }); })();

  // Initial pass
  (function init(){ var sec=resolveDurationSec(); if (sec!=null) updateBadge(sec); })();

})(window, document);

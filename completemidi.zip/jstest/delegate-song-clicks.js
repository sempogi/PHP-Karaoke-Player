// Delegated click binding for dynamically injected #playlist rows.
// Works with partial refresh (no need to re-bind per row).

(function () {
  'use strict';

  // Bind once on a stable ancestor: prefer #browserPanel, fallback to #playlist
  const root = document.getElementById('browserPanel') || document.getElementById('playlist');
  if (!root) return;

  function activate(link) {
    const rel = link?.dataset?.path;
    if (!rel) return;

    // Your existing queue function (prefer this)
    if (typeof window.queueSong === 'function') {
      window.queueSong(rel);
      return;
    }

    // Fallback: dispatch an event for your app to handle
    document.dispatchEvent(new CustomEvent('queueSong', { detail: { path: rel } }));
  }

  // Clicks on anchors with class .song (and their child elements)
  root.addEventListener('click', (e) => {
    const link = e.target.closest('a.song');
    if (!link || !root.contains(link)) return;

    // Prevent default "#" navigation
    e.preventDefault();
    activate(link);
  });

  // Optional: keyboard accessibility (Enter / Space on focused link)
  root.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const link = e.target.closest('a.song');
    if (!link || !root.contains(link)) return;

    e.preventDefault();
    activate(link);
  });
})();
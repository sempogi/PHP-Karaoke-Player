/*! screensaver_karaoke_panel_display_only_v3.4.2.js
 * Sem • 2025-10-18
 * Option B→A: Rotate wiki TOPICS for same song for 1 minute, then random song per minute.
 * Preserves: Control Center (Enable/Delay/Speed/Blur/Opacity/Mode/Interactive),
 *            blur/opacity, pixel-perfect vertical marquee, album art.
 */

(function(){
  // ---------- Config ----------
  // Optional local covers folder (by MIDI stem). Example: '/covers'
  var COVERS_BASE = null;

  // Fast responsiveness & wiki limits
  var WIKI_TIMEOUT_MS  = 1500;
  var THUMB_TIMEOUT_MS = 1500;
  var WIKI_MAX_CHARS   = 900;

  // Rotation timings
  var B_PHASE_MS       = 60000;  // 1 minute in Option B (topic rotation for same song)
  var B_STEP_MS        = 12000;  // ~12s step to cover ~5 topics within 60s
  var A_STEP_MS        = 60000;  // 1 minute per song in Option A (random song rotation)

  // ---------- Helpers ----------
  function onReady(fn){ if(document.readyState!=='loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }
  function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
  function $(id){ return document.getElementById(id); }
  function esc(s){ return (s==null?'':String(s)).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'})[c]); }
  function stemFromPath(p){ try{ var fn=String(p||'').split('/').pop(); return fn? fn.replace(/\.[^.]+$/,'') : ''; }catch(_){ return ''; } }
  // Safer minimal CSS.escape fallback
  if (!window.CSS || typeof CSS.escape!=='function'){
    window.CSS=(window.CSS||{});
    CSS.escape=function(s){ return String(s).replace(/([^\w-])/g,'\\$1'); };
  }

  // ---------- Settings (persist) ----------
  var ssEnable   = (localStorage.getItem('ssEnable')    || 'on')==='on';
  var ssDelayMin = clamp(parseInt(localStorage.getItem('ssDelayMin')||'2',10)||2, 1, 60);
  var ssSpeed    = clamp(parseFloat(localStorage.getItem('ssSpeed')   ||'22')||22, 6, 80); // px/s
  var ssMode     = (localStorage.getItem('ssMode')      || 'panel'); // 'panel' | 'full'
  var ssBlur     = clamp(parseInt(localStorage.getItem('ssBlur')      ||'8',10)||8, 0, 20);
  var ssOpacity  = clamp(parseFloat(localStorage.getItem('ssOpacity') ||'0.65')||0.65, 0.35, 0.95);
  var ssInteract = (localStorage.getItem('ssInteract')  || 'interactive'); // 'interactive' | 'strict'

  // ---------- State ----------
  var tIdle=null, host=null, box=null, view=null, track=null, track2=null;
  var ssArtWrap=null, ssArtImg=null, ssTitleEl=null, ssArtistEl=null, ssFactsEl=null, ssWikiEl=null, ssWikiTopicEl=null;

  // Rotation state
  var wikiTimer = null;
  var phaseTimer = null;
  var currentPhase = 'B'; // 'B' for topic rotation (same song), then 'A' for random song
  var ssSessionPick = null; // locked pick during Phase B
  var wikiKeyIdx = 0;       // topic index within Phase B

  // ---------- CSS ----------
  function injectCSS(){
    if ($('ssp-css-v3-4-2')) return;
    var st=document.createElement('style'); st.id='ssp-css-v3-4-2';
    st.textContent = [
      '#ssHost{position:fixed;inset:0;z-index:350;display:none;}',
      '#ssHost.panel{display:block;}',
      '#ssBox{--ssBlur:'+ssBlur+'px;--ssOpacity:'+ssOpacity+';position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(1000px,92vw);height:min(78vh,92vh);background:rgba(0,0,0,var(--ssOpacity));backdrop-filter:blur(var(--ssBlur));-webkit-backdrop-filter:blur(var(--ssBlur));border-radius:14px;border:1px solid rgba(255,255,255,.12);box-shadow:0 14px 44px rgba(0,0,0,.38);display:flex;flex-direction:column;overflow:hidden;}',
      '#ssHost.full #ssBox{left:0;top:0;transform:none;width:100vw;height:100vh;border-radius:0;}',
      '#ssHead{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:rgba(17,17,17,.45);border-bottom:1px solid rgba(255,255,255,.08)}',
      '#ssTitleBar{font-weight:800;letter-spacing:.02em;color:#bfe5ff}',
      '#ssHint{color:#a9b5c2;font:12px/1.2 system-ui}',
      '#ssCenter{display:grid;grid-template-columns:160px 1fr;gap:16px;align-items:start;padding:16px 18px 8px;}',
      '#ssArtWrap{width:160px;height:160px;border-radius:12px;overflow:hidden;background:#111;border:1px solid rgba(255,255,255,.1)}',
      '#ssArt{width:100%;height:100%;object-fit:cover;display:block}',
      '#ssMeta{min-width:0;display:flex;flex-direction:column;gap:8px;}',
      '#ssTitleLine{font-weight:800;color:#eaf4ff;line-height:1.15;font-size:clamp(18px,3.8vw,34px);text-wrap:balance;text-shadow:0 1px 2px rgba(0,0,0,.5)}',
      '#ssArtistLine{color:#d4e8ff;opacity:.92;font:600 clamp(14px,2.2vw,18px)/1.2 system-ui}',
      '#ssFacts{display:flex;flex-wrap:wrap;gap:6px}',
      '.fact{font:600 12px/1 system-ui;color:#1b2430;background:#ffffff;opacity:.9;border-radius:999px;padding:.32em .6em}',
      '#ssWikiBox{padding:0 18px 10px;color:#cfe2ff;font:14px/1.45 system-ui;max-height:7.5em;overflow:hidden;text-wrap:pretty}',
      '#ssWikiTopic{display:inline-block;margin:0 0 6px 0}',
      '#ssView{position:relative;flex:1 1 auto;overflow:hidden;background:transparent;-webkit-mask-image:linear-gradient(to bottom,transparent 0,#000 6%,#000 94%,transparent 100%);mask-image:linear-gradient(to bottom,transparent 0,#000 6%,#000 94%,transparent 100%)}',
      '#ssTrack,#ssTrack2{position:absolute;left:0;right:0;will-change:transform}',
      '.ssRow{display:flex;gap:12px;align-items:center;padding:8px 12px;border-bottom:1px solid rgba(255,255,255,.06)}',
      '.ssIdx{width:3.5em;text-align:right;color:#9fb6c9;font:12px/1.2 monospace}',
      '.ssName{flex:1 1 auto;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '@media (max-width:720px){#ssCenter{grid-template-columns:1fr}#ssArtWrap{width:128px;height:128px}}'
    ].join('\n');
    document.head.appendChild(st);
  }

  // ---------- DOM ----------
  function ensureDOM(){
    if (host) return host;
    injectCSS();
    host = document.createElement('div'); host.id='ssHost';
    host.innerHTML =
      '<div id="ssBox">'
    + '  <div id="ssHead"><div id="ssTitleBar">&#127926; Screensaver</div><div id="ssHint">Any key = Close • Idle starts after delay</div></div>'
    + '  <div id="ssCenter">'
    + '    <div id="ssArtWrap"><img id="ssArt" alt=""></div>'
    + '    <div id="ssMeta">'
    + '      <div id="ssTitleLine"></div>'
    + '      <div id="ssArtistLine"></div>'
    + '      <div id="ssFacts"></div>'
    + '    </div>'
    + '  </div>'
    + '  <div id="ssWikiBox"><span id="ssWikiTopic" class="fact" style="display:none"></span><div id="ssWikiText"></div></div>'
    + '  <div id="ssView"><div id="ssTrack"></div><div id="ssTrack2"></div></div>'
    + '</div>';
    document.body.appendChild(host);

    box = $('ssBox'); view = $('ssView'); track = $('ssTrack'); track2 = $('ssTrack2');
    ssArtWrap = $('ssArtWrap'); ssArtImg = $('ssArt'); ssTitleEl = $('ssTitleLine');
    ssArtistEl = $('ssArtistLine'); ssFactsEl = $('ssFacts'); ssWikiEl = $('ssWikiText'); ssWikiTopicEl = $('ssWikiTopic');
    return host;
  }

  // ---------- Utilities ----------
  function isVisible(){
    return !!(host && host.style.display !== 'none' && host.classList.contains('panel'));
  }

  // ---------- Playlist (strict: #playlist .row a.song) ----------
  function collectSongs(){
    var list = document.getElementById('playlist');
    if (!list) return [];
    var rows = list.querySelectorAll('.row a.song');
    if (!rows || !rows.length) return [];
    var out=[];
    rows.forEach(function(a){
      var row = a.closest('.row');
      if (row && row.style && row.style.display==='none') return;
      var name=(a.textContent||'').trim();
      var path=a.getAttribute('data-path')||'';
      if(!name) return;
      var hint = a.getAttribute('data-thumb') || a.getAttribute('data-cover') ||
                 (row && (row.querySelector('img[data-thumb], img.cover, img.thumb, img')?.src || null));
      out.push({ name:name, path:path, thumb:hint });
    });
    return out;
  }

  function parseArtistTitle(s){
    var str=String(s||'').trim();
    var sep = (str.indexOf(' — ')>=0) ? ' — ' : (str.indexOf(' - ')>=0 ? ' - ' : null);
    if(!sep) return { title:str, artist:'' };
    var parts=str.split(sep);
    return { artist:parts[0].trim(), title:parts.slice(1).join(sep).trim() };
  }
  function pickRandom(arr){ if(!arr||!arr.length) return null; return arr[(Math.random()*arr.length)|0]; }

  // ---------- Local meta (offline) ----------
  function getLocalMeta(){
    var si={};
    try{ if(window.SongInfo && typeof SongInfo.getCurrent==='function') si = SongInfo.getCurrent()||{}; }catch(_){}
    si.title       = si.title       || window.nowTitle  || window.nowPlayingTitle || '';
    si.artist      = si.artist      || window.nowArtist || window.nowPlayingArtist || '';
    si.album       = si.album       || window.nowAlbum  || '';
    si.year        = si.year        || window.nowYear   || '';
    si.genre       = si.genre       || window.nowGenre  || '';
    si.label       = si.label       || window.nowLabel  || '';
    si.country     = si.country     || window.nowCountry|| '';
    si.trackNumber = si.trackNumber || window.nowTrackNo|| null;
    si.trackCount  = si.trackCount  || window.nowTrackCount || null;
    si.bpm         = si.bpm         || window.nowBPM    || null;
    si.key         = si.key         || window.nowKey    || '';
    var d=null;
    try{ if (typeof window.songDurationSec==='number') d=Math.floor(window.songDurationSec);}catch(_){}
    try{ if (typeof window.songDurationMs==='number') d=Math.floor(window.songDurationMs/1000);}catch(_){}
    try{ if (typeof window.totalMs==='number')        d=Math.floor(window.totalMs/1000);}catch(_){}
    si.durationSec = d;
    return si;
  }
  function fmtDur(sec){ if(sec==null) return ''; sec=Math.max(0,sec|0); var h=sec/3600|0,m=(sec%3600)/60|0,s=sec%60; var mm=h?String(m).padStart(2,'0'):String(m), ss=String(s).padStart(2,'0'); return h?(`${h}:${mm}:${ss}`):(`${mm}:${ss}`); }
  function renderFacts(si){
    var facts=[];
    if (si.album)                        facts.push(['Album', si.album]);
    if (si.year)                         facts.push(['Year',  si.year]);
    if (si.genre)                        facts.push(['Genre', si.genre]);
    if (si.label)                        facts.push(['Label', si.label]);
    if (si.country)                      facts.push(['Country', si.country]);
    if (si.trackNumber && si.trackCount) facts.push(['Track',  si.trackNumber+' / '+si.trackCount]);
    else if (si.trackNumber)             facts.push(['Track',  String(si.trackNumber)]);
    if (si.bpm)                          facts.push(['Tempo',  si.bpm+' BPM']);
    if (si.key)                          facts.push(['Key',    si.key]);
    if (si.durationSec!=null)            facts.push(['Duration', fmtDur(si.durationSec)]);
    ssFactsEl.innerHTML = facts.map(function(f){ return '<span class="fact">'+esc(f[0]+': '+f[1])+'</span>'; }).join('');
  }

  // ---------- Fetch with timeout ----------
  function fetchTO(url, ms){
    try {
      var ctrl = new AbortController();
      var t = setTimeout(function(){ try{ ctrl.abort(); }catch(_){ } }, ms || WIKI_TIMEOUT_MS);
      return fetch(url, { signal: ctrl.signal }).finally(function(){ clearTimeout(t); });
    } catch(_){ return Promise.resolve(null); }
  }

  // ---------- Derive deterministic keys ----------
  function deriveTitleArtist(pick, meta){
    var stem  = pick?.path ? stemFromPath(pick.path) : '';
    var AT    = pick?.name ? parseArtistTitle(pick.name) : { title:'', artist:'' };
    var title = (meta?.title || AT.title || stem || 'Now Playing').trim();
    var artist= (meta?.artist || AT.artist || '').trim();
    return { title, artist };
  }

  // ---------- Wiki helpers ----------
  function parseWikiSummaryJson(j){
    if (!j) return '';
    var text = j.extract || '';
    if (!text && j.extract_html){ var tmp=document.createElement('div'); tmp.innerHTML=j.extract_html; text = tmp.textContent || ''; }
    text = String(text||'').trim(); if (!text) return '';
    var para = text.split(/\n{2,}/)[0].trim();
    return (para.length > WIKI_MAX_CHARS) ? (para.slice(0, WIKI_MAX_CHARS-1)+'…') : para;
  }

  function wikiSummaryByKey(key){
    var u = 'https://en.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(key);
    return fetchTO(u, WIKI_TIMEOUT_MS).then(function(r){
      if (!r || !r.ok) return '';
      return r.json().then(parseWikiSummaryJson).catch(function(){ return ''; });
    }).catch(function(){ return ''; });
  }

  var Wiki={cache:{}, inflight:{}};
  function getWikiCachedKey(key, onReady){
    var hit = Wiki.cache[key];
    if (hit != null) return hit;
    if (!Wiki.inflight[key]){
      Wiki.inflight[key] = true;
      wikiSummaryByKey(key)
        .then(function(txt){ Wiki.cache[key] = txt || ''; })
        .catch(function(){ Wiki.cache[key] = ''; })
        .finally(function(){ Wiki.inflight[key] = false; try{ onReady && onReady(Wiki.cache[key]); }catch(_){ } });
    }
    return '';
  }

  // Build topic->keys for Option B (same song, rotate topics)
  function buildTopicKeys(title, artist, meta){
    title  = String(title||'').trim();
    artist = String(artist||'').trim();
    var topics = [];

    // Song history (if possible)
    if (title){
      topics.push({
        label: 'Song',
        keys: [title+' (song)', title+' (single)', title]
      });
    }

    // Label / copyright holder (if meta.label exists)
    if (meta && meta.label){
      topics.push({
        label: 'Label',
        keys: [meta.label+' (record label)', meta.label]
      });
    }

    // Album
    if (meta && meta.album){
      topics.push({
        label: 'Album',
        keys: [meta.album+' (album)', meta.album]
      });
    }

    // Trivia (best effort: reuse song keys; summaries won’t expose trivia sections, but gives background)
    if (title){
      topics.push({
        label: 'Trivia',
        keys: [title+' (song)', title]
      });
    }

    // Artist history
    if (artist){
      topics.push({
        label: 'Artist',
        keys: [artist]
      });
    }

    // If nothing present, at least show artist or title
    if (!topics.length && (title || artist)){
      topics.push({label:'Info', keys:[title||artist]});
    }
    return topics;
  }

  function setTopicBadge(label){
    if (!ssWikiTopicEl) return;
    if (!label){ ssWikiTopicEl.style.display='none'; ssWikiTopicEl.textContent=''; return; }
    ssWikiTopicEl.style.display='';
    ssWikiTopicEl.textContent = label;
  }

  // ---------- Album art ----------
  function loadImgCandidates(img, urls){
    if (!img || !urls || !urls.length){ hideArt(); return; }
    var i=0; (function next(){
      if (i>=urls.length){ hideArt(); return; }
      var u=urls[i++]; if(!u){ next(); return; }
      var tmp=new Image(); tmp.onload=function(){ showArt(u); }; tmp.onerror=next; tmp.src=u;
    })();
  }
  function showArt(src){ if(!ssArtImg||!ssArtWrap) return; ssArtImg.src=src; ssArtWrap.style.display=''; }
  function hideArt(){ if(!ssArtImg||!ssArtWrap) return; ssArtImg.removeAttribute('src'); ssArtWrap.style.display='none'; }

  function resolveArtFor(pick){
    if (!pick){ hideArt(); return; }
    if (pick.thumb){ loadImgCandidates(ssArtImg,[pick.thumb]); return; }
    if (pick.path){
      var link=document.querySelector('#playlist a.song[data-path="'+CSS.escape(pick.path)+'"]');
      var row = link && link.closest('.row');
      var rowImg = row && (row.querySelector('img[data-thumb], img.cover, img.thumb, img')?.src || null);
      if (rowImg){ loadImgCandidates(ssArtImg,[rowImg]); return; }
    }
    if (COVERS_BASE && pick.path){
      var stem=stemFromPath(pick.path), base=COVERS_BASE.replace(/\/$/,'');
      loadImgCandidates(ssArtImg,[base+'/'+stem+'.webp', base+'/'+stem+'.jpg', base+'/'+stem+'.png']); return;
    }
    // Last resort: quick wiki thumb by title only (same short timeout)
    var AT=parseArtistTitle(pick.name);
    var t=String(AT.title||'').trim();
    if (!t){ hideArt(); return; }
    var u='https://en.wikipedia.org/api/rest_v1/page/summary/'+encodeURIComponent(t);
    fetchTO(u, THUMB_TIMEOUT_MS).then(function(r){
      if (!r || !r.ok) { hideArt(); return; }
      r.json().then(function(j){
        var src = j && (j.originalimage?.source || j.thumbnail?.source);
        if (src) loadImgCandidates(ssArtImg,[src]); else hideArt();
      }).catch(hideArt);
    }).catch(hideArt);
  }

  // ---------- Scrolling list (pixel-perfect, no overlap) ----------
  function buildListHTML(){
    var songs=collectSongs();
    if (!songs.length) return '<div class="ssRow"><div class="ssName">No songs found. Put files under /midi/</div></div>';
    var html='',i=0;
    songs.forEach(function(s){ i++; html+='<div class="ssRow"><div class="ssIdx">'+String(i).padStart(3,'0')+'.</div><div class="ssName">'+esc(s.name)+'</div></div>'; });
    return html;
  }

  function startScroll(){
    if(!host) return;
    var built = buildListHTML();
    track.innerHTML  = built;
    track2.innerHTML = built;

    var contentH = track.scrollHeight || track.getBoundingClientRect().height || 1000;

    track.style.top  = '0px';
    track2.style.top = contentH + 'px';

    var pps    = Math.max(6, ssSpeed);
    var durSec = Math.max(10, Math.round(contentH / pps));
    var dur    = durSec + 's';

    var st = document.getElementById('ss-marquee-dyn');
    if (!st){ st = document.createElement('style'); st.id='ss-marquee-dyn'; document.head.appendChild(st); }
    var NAME = 'vmarquee_px';
    st.textContent = '@keyframes '+NAME+'{ from{ transform:translateY(0) } to{ transform:translateY(-'+contentH+'px) } }';

    track.style.animation  = NAME+' '+dur+' linear infinite';
    track2.style.animation = NAME+' '+dur+' linear infinite';
  }

  // ---------- Look & show/hide ----------
  function applyLook(){
    if(!box) return;
    box.style.setProperty('--ssBlur', ssBlur+'px');
    box.style.setProperty('--ssOpacity', String(ssOpacity));
    host.classList.toggle('full', ssMode==='full');
  }

  // ---------- Rotation engine ----------
  function stopWikiRotation(){ if (wikiTimer){ clearInterval(wikiTimer); wikiTimer=null; } }
  function stopPhaseTimer(){ if (phaseTimer){ clearTimeout(phaseTimer); phaseTimer=null; } }

  function stepOptionB(){
    // Same song; rotate topics
    if (!isVisible()){ stopWikiRotation(); stopPhaseTimer(); return; }

    // Ensure we have a session pick
    var songs = collectSongs();
    if (!ssSessionPick) ssSessionPick = pickRandom(songs);
    var pick  = ssSessionPick;
    var meta  = getLocalMeta();
    var TA    = deriveTitleArtist(pick, meta);

    // Static title/artist/art during Phase B
    ssTitleEl.textContent  = TA.title || 'Unknown Title';
    ssArtistEl.textContent = TA.artist || '';
    renderFacts(meta);
    if (pick) resolveArtFor(pick); else hideArt();

    var topics = buildTopicKeys(TA.title, TA.artist, meta);
    if (!topics.length){ setTopicBadge(''); ssWikiEl.textContent=''; return; }

    var tIdx  = wikiKeyIdx % topics.length;
    var topic = topics[tIdx];
    wikiKeyIdx++;

    // Try keys in order for this topic
    (function tryKey(i){
      if (i>=topic.keys.length){ /* all failed */ return; }
      var key = topic.keys[i];
      var hit = Wiki.cache[key];
      setTopicBadge(topic.label);
      if (hit != null){
        if (isVisible()) ssWikiEl.textContent = hit || '';
        if (!hit) tryKey(i+1);
        return;
      }
      ssWikiEl.textContent = 'Fetching wiki…';
      wikiSummaryByKey(key).then(function(txt){
        Wiki.cache[key] = txt || '';
        if (!isVisible()) return;
        if (Wiki.cache[key]) ssWikiEl.textContent = Wiki.cache[key];
        else tryKey(i+1);
      });
    })(0);
  }

  function stepOptionA(){
    // Random song each minute
    if (!isVisible()){ stopWikiRotation(); stopPhaseTimer(); return; }

    var songs = collectSongs();
    var pick  = pickRandom(songs);
    var meta  = getLocalMeta();
    var TA    = deriveTitleArtist(pick, meta);

    ssTitleEl.textContent  = TA.title || 'Unknown Title';
    ssArtistEl.textContent = TA.artist || '';
    renderFacts(meta);
    if (pick) resolveArtFor(pick); else hideArt();

    setTopicBadge(''); // No specific topic label in Option A (full random)

    // Use title-first key (song bias) then fallback
    var keys = [];
    if (TA.title) keys.push(TA.title+' (song)', TA.title);
    if (TA.artist) keys.push(TA.artist);
    var shown=false;

    (function nextKey(i){
      if (i>=keys.length){ if (!shown) ssWikiEl.textContent=''; return; }
      var k = keys[i];
      var hit = Wiki.cache[k];
      if (hit != null){
        if (isVisible()){ ssWikiEl.textContent = hit || ssWikiEl.textContent; shown = !!hit; }
        if (!hit) nextKey(i+1);
        return;
      }
      ssWikiEl.textContent = 'Fetching wiki…';
      wikiSummaryByKey(k).then(function(txt){
        Wiki.cache[k] = txt || '';
        if (!isVisible()) return;
        if (Wiki.cache[k]){ ssWikiEl.textContent = Wiki.cache[k]; shown = true; }
        else nextKey(i+1);
      });
    })(0);
  }

  function startPhaseBThenA(){
    stopWikiRotation(); stopPhaseTimer();
    currentPhase = 'B';
    wikiKeyIdx = 0;
    ssSessionPick = null;
    // Kick an immediate render and start topic rotation
    stepOptionB();
    wikiTimer = setInterval(stepOptionB, B_STEP_MS);
    // After B_PHASE_MS, switch to Option A schedule
    phaseTimer = setTimeout(function(){
      if (!isVisible()) { stopWikiRotation(); return; }
      currentPhase = 'A';
      stopWikiRotation();
      stepOptionA();
      wikiTimer = setInterval(stepOptionA, A_STEP_MS);
    }, B_PHASE_MS);
  }

  function showOverlay(){
    cancelIdle();               // avoid re-triggers while visible
    ensureDOM();
    applyLook();

    // Start with Phase B then transition to A
    startPhaseBThenA();

    host.classList.add('panel');
    host.style.display='';
    startScroll();
  }

  function hideOverlay(force){
    if (host) { host.classList.remove('panel'); host.style.display='none'; }
    if (force){ cancelIdle(); }
    stopWikiRotation();
    stopPhaseTimer();
    ssSessionPick = null;
    wikiKeyIdx = 0;
  }

  // ---------- Idle ----------
  function cancelIdle(){ if(tIdle){ clearTimeout(tIdle); tIdle=null; } }
  function scheduleIdle(){
    cancelIdle();
    if(!ssEnable) return;
    try{ if(window.isPlaying) return; }catch(_){}
    if (isVisible()) return; // do not rearm while showing
    tIdle = setTimeout(function(){
      try{
        if(!window.isPlaying && !isVisible()) showOverlay();
      }catch(_){
        if(!isVisible()) showOverlay();
      }
    }, ssDelayMin*60*1000);
  }
  function markActive(){
    if (ssInteract === 'strict') hideOverlay(true);
    scheduleIdle();
  }

  // ---------- Status hook (optional) ----------
  function hookStatus(){
    if (typeof window.setStatus!=='function') return;
    if (window.__origSetStatusSSP_v3_4_2) return; window.__origSetStatusSSP_v3_4_2 = window.setStatus;
    window.setStatus = function(msg){
      try{ window.__origSetStatusSSP_v3_4_2 && window.__origSetStatusSSP_v3_4_2(msg); }catch(_){}
      try{
        if (msg==='PLAYING'){ hideOverlay(true); cancelIdle(); }
        else if (msg==='IDLE'){ if(ssEnable && !isVisible()) scheduleIdle(); }
      }catch(_){}
    };
  }

  // ---------- Activity listeners ----------
  function bindActivity(){
    ['mousemove','keydown','click','touchstart','wheel'].forEach(function(ev){
      document.addEventListener(ev, markActive, {passive:true});
    });

    if (ssInteract === 'interactive') {
      // Any key closes
      document.addEventListener('keydown', function(){
        if(!host || host.style.display==='none') return;
        hideOverlay(true);
      }, true);

      // Close when clicking OUTSIDE the panel box (#ssBox)
      document.addEventListener('mousedown', function(e){
        if(!host || host.style.display==='none') return;
        if (box && !box.contains(e.target)) hideOverlay(true);
      }, true);
      document.addEventListener('touchstart', function(e){
        if(!host || host.style.display==='none') return;
        if (box && !box.contains(e.target)) hideOverlay(true);
      }, {passive:true, capture:true});
    }
  }

  // ---------- Control Center (preserved) ----------
  function injectCC(){
    var cc=$('ccPanel'); if(!cc) return;
    var list=cc.querySelector('.list'); if(!list) return;
    if($('ccSSRow')) return;

    var row=document.createElement('div'); row.className='row'; row.id='ccSSRow';
    row.innerHTML =
      '<span class="label">Screensaver</span>'+
      '<label class="small"><input type="checkbox" id="ccSSOn"> Enable</label>'+
      '<div class="chips" style="margin-left:8px" id="ccSSMode">'+
        '<button class="small" data-mode="panel">Panel</button>'+
        '<button class="small" data-mode="full">Full</button>'+
      '</div>'+
      '<label class="small" style="margin-left:8px">After <input type="range" id="ccSSDelay" min="1" max="15" step="1" style="width:120px"> <span id="ccSSDelayLbl" class="small"></span> min</label>'+
      '<label class="small" style="margin-left:8px">Speed <input type="range" id="ccSSSpeed" min="6" max="80" step="1" style="width:120px"> <span id="ccSSSpeedLbl" class="small"></span> px/s</label>'+
      '<label class="small" style="margin-left:8px">Blur <input type="range" id="ccSSBlur" min="0" max="20" step="1" style="width:100px"> <span id="ccSSBlurLbl" class="small"></span></label>'+
      '<label class="small" style="margin-left:8px">Opacity <input type="range" id="ccSSOp" min="35" max="95" step="1" style="width:100px"> <span id="ccSSOpLbl" class="small"></span>%</label>'+
      '<div class="chips" style="margin-left:8px" id="ccSSInteract">'+
        '<button class="small" data-interact="interactive" title="Any key/outside click hides">Interactive</button>'+
        '<button class="small" data-interact="strict" title="Hide on any activity">Strict</button>'+
      '</div>'+
      '<button id="ccSSStart" class="small" style="margin-left:8px" title="Start now">Start Now</button>'+
      '<button id="ccSSStop"  class="small" title="Stop">Stop</button>';
    list.appendChild(row);

    var on=$('ccSSOn'), d=$('ccSSDelay'), dl=$('ccSSDelayLbl'),
        sp=$('ccSSSpeed'), spl=$('ccSSSpeedLbl'),
        bm=$('ccSSMode'), bl=$('ccSSBlur'), bll=$('ccSSBlurLbl'),
        op=$('ccSSOp'),  opl=$('ccSSOpLbl');
    var go=$('ccSSStart'), stop=$('ccSSStop');
    var inter=$('ccSSInteract');

    function paint(){
      if(on) on.checked=ssEnable;
      if(d){ d.value=String(ssDelayMin); dl.textContent=String(ssDelayMin); }
      if(sp){ sp.value=String(ssSpeed);  spl.textContent=String(ssSpeed); }
      if(bm){ bm.querySelectorAll('button').forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-mode')===ssMode); }); }
      if(bl){ bl.value=String(ssBlur);   bll.textContent=ssBlur+'px'; }
      if(op){ op.value=String(Math.round(ssOpacity*100)); opl.textContent=String(Math.round(ssOpacity*100)); }
      if(inter){ inter.querySelectorAll('button').forEach(function(b){ b.classList.toggle('active', b.getAttribute('data-interact')===ssInteract); }); }
    }
    paint();

    on.addEventListener('change', function(){ ssEnable = on.checked; try{ localStorage.setItem('ssEnable', ssEnable?'on':'off'); }catch(_){ } if(!ssEnable) hideOverlay(true); else scheduleIdle(); });
    d.addEventListener('input',  function(){ var v=parseInt(d.value,10)||2; v=clamp(v,1,15); dl.textContent=String(v); });
    d.addEventListener('change', function(){ var v=parseInt(d.value,10)||2; v=clamp(v,1,15); ssDelayMin=v; try{ localStorage.setItem('ssDelayMin', String(v)); }catch(_){ } scheduleIdle(); });
    sp.addEventListener('input', function(){ var v=parseInt(sp.value,10)||22; v=clamp(v,6,80); spl.textContent=String(v); });
    sp.addEventListener('change',function(){ var v=parseInt(sp.value,10)||22; v=clamp(v,6,80); ssSpeed=v; try{ localStorage.setItem('ssSpeed', String(ssSpeed)); }catch(_){ } if(host && host.style.display!=='none') startScroll(); });
    bm.addEventListener('click', function(e){ var b=e.target.closest('button[data-mode]'); if(!b) return; ssMode=b.getAttribute('data-mode')||'panel'; try{ localStorage.setItem('ssMode', ssMode); }catch(_){ } applyLook(); paint(); });
    bl.addEventListener('input',  function(){ var v=parseInt(bl.value,10)||8; v=clamp(v,0,20); bll.textContent=v+'px'; });
    bl.addEventListener('change', function(){ var v=parseInt(bl.value,10)||8; v=clamp(v,0,20); ssBlur=v; try{ localStorage.setItem('ssBlur', String(ssBlur)); }catch(_){ } applyLook(); });
    op.addEventListener('input',  function(){ var v=parseInt(op.value,10)||65; v=clamp(v,35,95); opl.textContent=String(v); });
    op.addEventListener('change', function(){ var v=parseInt(op.value,10)||65; v=clamp(v,35,95); ssOpacity=v/100; try{ localStorage.setItem('ssOpacity', String(ssOpacity)); }catch(_){ } applyLook(); });

    go.addEventListener('click',  function(){ showOverlay(); cancelIdle(); });
    stop.addEventListener('click',function(){ hideOverlay(true); });
  }

  // ---------- Init ----------
  onReady(function(){ ensureDOM(); bindActivity(); hookStatus(); injectCSS(); injectCC(); scheduleIdle(); });

  // Dev helper
  window.ssPanel = {
    show: () => showOverlay(),
    hide: () => hideOverlay(true),
    idle: () => scheduleIdle(),
    phase: () => currentPhase
  };
})();
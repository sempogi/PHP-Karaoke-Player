
/* === Song Info — Attach Guard (resilient UI entrypoints) ===
 * Purpose: keep UI access points visible even after feature changes.
 * Adds: Micro-dock → Panels → "Song Info" and Control Center → Tools → "Song Info (Online)"
 * Depends: your original song_info_online_patch.js (the first version) being loaded.
 * Behavior: On click, tries WM.songinfo.toggle(); if missing, waits until #songInfoPanel exists.
 */
(function(){
  function toggleSongInfo(){
    // Prefer WM if present
    if (window.WM && WM.songinfo && typeof WM.songinfo.toggle === 'function') {
      WM.songinfo.toggle();
      return true;
    }
    // Fallback: direct panel toggle
    var p = document.getElementById('songInfoPanel');
    if (p) {
      p.classList.toggle('visible');
      if (p.classList.contains('visible')) p.style.zIndex = '400';
      return true;
    }
    return false;
  }

  function waitForPanel(cb){
    var ok = toggleSongInfo();
    if (ok) { cb && cb(); return; }
    var mo = new MutationObserver(function(){
      if (toggleSongInfo()) { try{ mo.disconnect(); }catch(_){} cb && cb(); }
    });
    mo.observe(document.documentElement, { childList:true, subtree:true });
  }

  function addDockItem(){
    var menu = document.getElementById('mdPanelMenu'); if (!menu) return false;
    if (menu.querySelector('[data-open="songinfo-guard"]')) return true;
    var btn = document.createElement('button');
    btn.className = 'md-item'; btn.setAttribute('data-open','songinfo-guard');
    btn.textContent = 'Song Info';
    btn.addEventListener('click', function(){
      waitForPanel(function(){
        // close dock menu
        menu.classList.remove('open');
        var md = document.getElementById('mdPanel'); if (md) md.classList.remove('active');
      });
    });
    menu.appendChild(btn);
    return true;
  }

  function addCCTool(){
    var cc = document.getElementById('ccPanel'); if (!cc) return false;
    var list = cc.querySelector('.list'); if (!list) return false;
    var toolsRow = Array.prototype.slice.call(list.children).find(function(el){
      var lab = el.querySelector('.label'); return lab && /tools/i.test((lab.textContent||''));
    });
    if (!toolsRow){
      toolsRow = document.createElement('div'); toolsRow.className = 'row';
      var lab = document.createElement('span'); lab.className = 'label'; lab.textContent = 'Tools';
      toolsRow.appendChild(lab); list.insertBefore(toolsRow, list.firstChild);
    }
    if (toolsRow.querySelector('#btnSongInfoGuard')) return true;
    var wrap = document.createElement('span'); var a = document.createElement('a');
    a.id='btnSongInfoGuard'; a.href='#'; a.className='btn small'; a.textContent='Song Info (Online)';
    a.title='Open Song Info panel';
    a.addEventListener('click', function(e){ e.preventDefault(); waitForPanel(); });
    wrap.appendChild(a); toolsRow.appendChild(wrap);
    return true;
  }

  // Retry until targets exist
  (function hook(){ var tries=0, max=15; (function tick(){ tries++; var ok1=addDockItem(); var ok2=addCCTool(); if(!(ok1&&ok2) && tries<max){ setTimeout(tick, 400); } })(); })();
})();

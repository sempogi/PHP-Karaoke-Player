
/* FireworksBG — Pure JS Canvas background (no iframe, no video)
 * API: fireworksBG.start(opts), stop(), setZ(z), setOpacity(op), setWind(w), setDensity(d)
 * Options: { crackle:boolean, strobe:boolean, palm:boolean, crossette:boolean, density:number, wind:number, brightness:number, bloom:number }
 */
(function(){
  'use strict';
  const TAU = Math.PI*2;
  function rand(a,b){ return a + Math.random()*(b-a); }
  function randInt(a,b){ return (a + Math.floor(Math.random()*(b-a+1))); }
  function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
  function hsvToRgb(h,s,v){ h=(h%360+360)%360; const c=v*s, x=c*(1-Math.abs((h/60)%2-1)), m=v-c; let r=0,g=0,b=0; if(h<60){ r=c; g=x; } else if(h<120){ r=x; g=c; } else if(h<180){ g=c; b=x; } else if(h<240){ g=x; b=c; } else if(h<300){ r=x; b=c; } else { r=c; b=x; } return [(r+m)*255,(g+m)*255,(b+m)*255]; }

  const defaults = {
    gravity: 80, air: 0.988, sparkAir: 0.992,
    sparkLife: [1.2, 2.2], sparkCount: [130, 200], sparkSpeed: [160, 320],
    bloom: 1.9,
    wind: 0.08, trailAlpha: 0.12, auto: true, density: 0.7,
    crackle: true, crackleLife: [0.28, 0.55], crackleSpeed: [60, 140], crackleBurstRate: [22, 40], crackleDuration: [0.9, 1.5],
    strobe: true, pearlCount: [10, 28], pearlLife: [1.1, 2.0], pearlSpeed: [80, 160], pearlFreq: [8, 13], pearlDuty: [0.25, 0.42], pearlRadius: [2.5, 3.6],
    palm: true, palmFronds: [5, 8], palmSpeed: [240, 380], palmLife: [1.4, 2.2], palmTrailWidth: 2.4, palmEmberRate: [10, 18], palmEmberLife: [0.55, 1.1], palmHue: [45, 50, 60, 120, 130],
    crossette: true, crossSeeds: [6, 14], crossSplitTime: [0.35, 0.7], crossSplitCount: [4,4], crossSpeed: [120, 200], crossLife: [0.7, 1.3], crossJitter: 0.22, crossHue: [40, 50, 0, 200, 220],
    brightness: 0.95, bloomScale: 1.0
  };

  let canvas, ctx, dpr=1, W=0, H=0, rafId=null;
  let params = Object.assign({}, defaults);
  const pool=[], rockets=[], emitters=[], pearls=[], palms=[], cseeds=[];

  function ensureCanvas(){
    if(canvas) return;
    canvas = document.createElement('canvas');
    canvas.id = 'fireworks-bgfx';
    canvas.style.position = 'fixed';
    canvas.style.inset = '0';
    canvas.style.zIndex = '80';
    canvas.style.pointerEvents = 'none';
    canvas.style.opacity = '1';
    canvas.style.filter = `brightness(${params.brightness})`;
    canvas.style.background = 'radial-gradient(1200px 420px at 50% 80%, #0b1020 0%, #05070f 65%, #02040a 100%)';
    document.body.appendChild(canvas);
    ctx = canvas.getContext('2d');
    resize();
    window.addEventListener('resize', resize);
  }
  function resize(){ W = window.innerWidth; H = window.innerHeight; canvas.width = W; canvas.height = H; }

  function fadeScene(){ ctx.save(); ctx.globalCompositeOperation='source-over'; ctx.fillStyle = 'rgba(2,3,8,'+params.trailAlpha+')'; ctx.fillRect(0,0,W,H); ctx.restore(); }
  function drawGlow(x,y, r, rgb, alpha){ const g = ctx.createRadialGradient(x,y,0, x,y,r); const c0 = 'rgba('+rgb[0]+','+rgb[1]+','+rgb[2]+','+(alpha==null?1:alpha)+')'; const c1 = 'rgba('+rgb[0]+','+rgb[1]+','+rgb[2]+',0)'; g.addColorStop(0, c0); g.addColorStop(1, c1); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x,y,r,0,TAU); ctx.fill(); }

  class Spark{ constructor(x,y,vx,vy,rgb,life,kind){ this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.rgb=rgb; this.life=life; this.t=0; this.kind=kind||'spark'; this.trail=[]; this.maxTrail=6; this.w= 1; this.flicker = Math.random()*TAU; }
    update(dt){ this.t += dt; if(this.t>this.life) return false; const air = this.kind==='crackle'? 0.975 : params.sparkAir; this.vx *= air; this.vy = this.vy*air + params.gravity*dt*(this.kind==='crackle'?0.6:1.0); this.vx += params.wind*6*dt; this.x += this.vx*dt; this.y += this.vy*dt; this.trail.push([this.x,this.y]); if(this.trail.length>this.maxTrail) this.trail.shift(); return true; }
    draw(){ const p = clamp(this.t/this.life,0,1); let alpha=(1-p)*(1-p); if(this.kind==='crackle') alpha *= (0.65 + 0.35*Math.abs(Math.sin(this.flicker + this.t*18))); ctx.save(); ctx.globalCompositeOperation='lighter'; for(let i=1;i<this.trail.length;i++){ const a=this.trail[i-1], b=this.trail[i]; ctx.strokeStyle='rgba('+this.rgb[0]+','+this.rgb[1]+','+this.rgb[2]+','+(alpha*0.28)+')'; ctx.lineWidth = 1 * (i/this.trail.length); ctx.beginPath(); ctx.moveTo(a[0],a[1]); ctx.lineTo(b[0],b[1]); ctx.stroke(); } drawGlow(this.x,this.y, 3.0*params.bloom*params.bloomScale, this.rgb, alpha); ctx.restore(); } }

  class StrobePearl{ constructor(x,y,vx,vy,rgb,life,freq,duty,rad){ this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.rgb=rgb; this.life=life; this.t=0; this.freq=freq; this.duty=duty; this.radius=rad; this.phase=Math.random(); this.trail=[]; this.maxTrail=3; }
    update(dt){ this.t += dt; if(this.t>this.life) return false; const air=0.988; this.vx*=air; this.vy=this.vy*air + params.gravity*dt*0.9; this.vx += params.wind*4*dt; this.x += this.vx*dt; this.y += this.vy*dt; this.trail.push([this.x,this.y]); if(this.trail.length>this.maxTrail) this.trail.shift(); return true; }
    draw(){ const cycles=(this.t*this.freq + this.phase); const frac = cycles - Math.floor(cycles); if(frac>this.duty) return; const p=this.t/this.life; const alpha=(1-p)*(1-p); ctx.save(); ctx.globalCompositeOperation='lighter'; for(let i=1;i<this.trail.length;i++){ const a=this.trail[i-1], b=this.trail[i]; ctx.strokeStyle='rgba('+this.rgb[0]+','+this.rgb[1]+','+this.rgb[2]+','+(0.16*alpha)+')'; ctx.lineWidth = 0.8 * (i/this.trail.length); ctx.beginPath(); ctx.moveTo(a[0],a[1]); ctx.lineTo(b[0],b[1]); ctx.stroke(); } drawGlow(this.x,this.y, this.radius*params.bloom*params.bloomScale, this.rgb, 0.95); ctx.restore(); } }

  class PalmComet{ constructor(x,y,vx,vy,rgb,life,tw,rate){ this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.rgb=rgb; this.life=life; this.t=0; this.trail=[]; this.maxTrail=14; this.trailW=tw; this.rate=rate; this.dead=false; }
    update(dt){ this.t += dt; if(this.t>this.life){ this.dead=true; return false; } const air=0.990; this.vx*=air; this.vy=this.vy*air + params.gravity*dt*0.85; this.vx += params.wind*3*dt; this.x += this.vx*dt; this.y += this.vy*dt; this.trail.push([this.x,this.y]); if(this.trail.length>this.maxTrail) this.trail.shift(); const n=Math.floor(this.rate*dt); for(let i=0;i<n;i++){ const ang=Math.random()*TAU; const spd=rand(40,90); const hue=params.palmHue[randInt(0, params.palmHue.length-1)]; const rgb=hsvToRgb(hue, rand(0.3,0.8),1.0); const vx=Math.cos(ang)*spd; const vy=Math.sin(ang)*spd*0.7 + rand(-50,10); const life=rand(params.palmEmberLife[0], params.palmEmberLife[1]); pool.push(new Spark(this.x, this.y, vx, vy, rgb, life, 'spark')); } return true; }
    draw(){ const p=clamp(this.t/this.life,0,1); const alpha=(1-p)*(1-p); ctx.save(); ctx.globalCompositeOperation='lighter'; for(let i=1;i<this.trail.length;i++){ const a=this.trail[i-1], b=this.trail[i]; ctx.strokeStyle='rgba('+this.rgb[0]+','+this.rgb[1]+','+this.rgb[2]+','+(0.22*alpha)+')'; ctx.lineWidth = this.trailW * (i/this.trail.length); ctx.beginPath(); ctx.moveTo(a[0],a[1]); ctx.lineTo(b[0],b[1]); ctx.stroke(); } drawGlow(this.x,this.y, 3.4*params.bloom*params.bloomScale, this.rgb, 0.95); ctx.restore(); } }

  class CrossetteSeed{ constructor(x,y,vx,vy,rgb,splitTime){ this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.rgb=rgb; this.t=0; this.splitTime=splitTime; this.dead=false; this.trail=[]; this.maxTrail=6; }
    update(dt){ if(this.dead) return false; this.t += dt; const air=0.990; this.vx*=air; this.vy=this.vy*air + params.gravity*dt*0.9; this.vx += params.wind*4*dt; this.x += this.vx*dt; this.y += this.vy*dt; this.trail.push([this.x,this.y]); if(this.trail.length>this.maxTrail) this.trail.shift(); if(this.t>=this.splitTime){ this.split(); this.dead=true; return false; } return true; }
    split(){ const count=4; const baseAng=Math.atan2(this.vy, this.vx); const arms=[0,1,2,3].map(k=> baseAng + k*(Math.PI/2) + rand(-params.crossJitter, params.crossJitter)); const spd=rand(params.crossSpeed[0], params.crossSpeed[1]); const life=rand(params.crossLife[0], params.crossLife[1]); const hue=params.crossHue[randInt(0, params.crossHue.length-1)]; const rgb=hsvToRgb(hue, rand(0.4,0.9), 1.0); arms.forEach(a=>{ const vx=Math.cos(a)*spd; const vy=Math.sin(a)*spd*0.85 - rand(5,35); pool.push(new Spark(this.x, this.y, vx, vy, rgb, life, 'spark')); }); if(params.crackle){ for(let i=0;i<randInt(4,8);i++){ const ang=Math.random()*TAU; const sp=rand(40,90); const rgb2=hsvToRgb(hue, rand(0.2,0.6), 1.0); const vx=Math.cos(ang)*sp; const vy=Math.sin(ang)*sp*0.8 - rand(0,30); const life2=rand(0.22,0.45); pool.push(new Spark(this.x, this.y, vx, vy, rgb2, life2, 'crackle')); } } }
    draw(){ const p=clamp(this.t/this.splitTime,0,1); const alpha=(1-p)*(1-p); ctx.save(); ctx.globalCompositeOperation='lighter'; for(let i=1;i<this.trail.length;i++){ const a=this.trail[i-1], b=this.trail[i]; ctx.strokeStyle='rgba('+this.rgb[0]+','+this.rgb[1]+','+this.rgb[2]+','+(0.22*alpha)+')'; ctx.lineWidth = 1.2 * (i/this.trail.length); ctx.beginPath(); ctx.moveTo(a[0],a[1]); ctx.lineTo(b[0],b[1]); ctx.stroke(); } drawGlow(this.x,this.y, 2.4*params.bloom*params.bloomScale, this.rgb, 0.95); ctx.restore(); } }

  function launchRandom(){ const baseX=rand(W*0.2, W*0.8), baseY=H*0.92; const targetX=rand(W*0.2, W*0.8), targetY=rand(H*0.22, H*0.45); rockets.push(new Shell(baseX, baseY, targetX, targetY)); }

  class Shell{ constructor(x,y,tx,ty){ this.x=x; this.y=y; this.tx=tx; this.ty=ty; this.exploded=false; const ang=Math.atan2(ty-y, tx-x); const speed=rand(500,720); this.vx=Math.cos(ang)*speed; this.vy=Math.sin(ang)*speed; this.t=0; this.smoke=[]; this.done=false; }
    update(dt){ if(this.done) return false; this.t+=dt; this.vx*=0.997; this.vy=this.vy*0.997 + params.gravity*dt*0.15; this.vx += params.wind*5*dt; this.x+=this.vx*dt; this.y+=this.vy*dt; this.smoke.push([this.x,this.y]); if(this.smoke.length>8) this.smoke.shift(); const near=Math.hypot(this.x-this.tx, this.y-this.ty) < 16; const slowing=this.vy>-30; if(!this.exploded && (near || slowing || this.y< H*0.18)){ this.explode(); this.exploded=true; this.done=true; return false; } return true; }
    explode(){ const count=Math.round(randInt(params.sparkCount[0], params.sparkCount[1]) * params.density); const hues=[45,0,200,120]; const sparks=[]; const type=randInt(0,3); for(let i=0;i<count;i++){ const hue=hues[randInt(0,hues.length-1)]; const rgb=hsvToRgb(hue, 0.9, 1.0); const ang=Math.random()*TAU; let spd=rand(params.sparkSpeed[0], params.sparkSpeed[1]); let life=rand(params.sparkLife[0], params.sparkLife[1]); if(type===2){ spd*=0.65; life*=1.6; } const vx=Math.cos(ang)*spd; const vy=Math.sin(ang)*spd*0.85 - rand(10,60); sparks.push(new Spark(this.x, this.y, vx, vy, rgb, life, 'spark')); } pool.push(...sparks); pool.push(new Spark(this.x, this.y, 0, 0, hsvToRgb(50,1,1), 0.5, 'flash'));
      if(params.crackle){ emitters.push(new CrackleCore(this.x, this.y)); }
      if(params.strobe){ const pearlN=randInt(params.pearlCount[0], params.pearlCount[1]); for(let i=0;i<pearlN;i++){ const hue=[40,50,0,200,220][randInt(0,4)]; const rgb=hsvToRgb(hue, 0.2 + Math.random()*0.6, 1.0); const ang=Math.random()*TAU; const spd=rand(params.pearlSpeed[0], params.pearlSpeed[1]); const life=rand(params.pearlLife[0], params.pearlLife[1]); const freq=rand(params.pearlFreq[0], params.pearlFreq[1]); const duty=rand(params.pearlDuty[0], params.pearlDuty[1]); const rad=rand(params.pearlRadius[0], params.pearlRadius[1]); const vx=Math.cos(ang)*spd; const vy=Math.sin(ang)*spd*0.85 - rand(5,30); pearls.push(new StrobePearl(this.x, this.y, vx, vy, rgb, life, freq, duty, rad)); } }
      if(params.palm){ const fronds=randInt(params.palmFronds[0], params.palmFronds[1]); const baseHue=params.palmHue[randInt(0, params.palmHue.length-1)]; for(let i=0;i<fronds;i++){ const ang=i*(TAU/fronds) + rand(-0.15, 0.15); const spd=rand(params.palmSpeed[0], params.palmSpeed[1]); const life=rand(params.palmLife[0], params.palmLife[1]); const rgb=hsvToRgb(baseHue + rand(-8,8), 0.9, 1.0); const vx=Math.cos(ang)*spd; const vy=Math.sin(ang)*spd*0.75 - rand(30, 90); const rate=rand(params.palmEmberRate[0], params.palmEmberRate[1]); palms.push(new PalmComet(this.x, this.y, vx, vy, rgb, life, params.palmTrailWidth, rate)); } }
      if(params.crossette){ const seeds=randInt(params.crossSeeds[0], params.crossSeeds[1]); for(let i=0;i<seeds;i++){ const hue=params.crossHue[randInt(0, params.crossHue.length-1)]; const rgb=hsvToRgb(hue, rand(0.4,0.9), 1.0); const ang=Math.random()*TAU; const spd=rand(100, 200); const vx=Math.cos(ang)*spd; const vy=Math.sin(ang)*spd*0.85 - rand(10,40); const tSplit=rand(params.crossSplitTime[0], params.crossSplitTime[1]); cseeds.push(new CrossetteSeed(this.x, this.y, vx, vy, rgb, tSplit)); } }
    }
    draw(){ ctx.save(); ctx.globalCompositeOperation='lighter'; for(let i=1;i<this.smoke.length;i++){ const a=this.smoke[i-1], b=this.smoke[i]; ctx.strokeStyle='rgba(255,220,150,0.12)'; ctx.lineWidth=1.2; ctx.beginPath(); ctx.moveTo(a[0],a[1]); ctx.lineTo(b[0],b[1]); ctx.stroke(); } drawGlow(this.x,this.y, 2.4*params.bloom*params.bloomScale, [255,240,190], 1); ctx.restore(); }
  }

  class CrackleCore{ constructor(x,y){ this.x=x; this.y=y; this.t=0; this.life = rand(0.9, 1.5); this.rate = rand(22, 40); this.hue = [45,50,55,20,0][randInt(0,4)]; this.dead=false; }
    update(dt){ if(this.dead) return false; this.t += dt; if(this.t>this.life){ this.dead=true; return false; } const n = Math.floor(this.rate * dt); for(let i=0;i<n;i++){ const ang=Math.random()*TAU; const spd=rand(60, 140); const rgb=hsvToRgb(this.hue, rand(0.2,0.7), 1.0); const vx=Math.cos(ang)*spd; const vy=Math.sin(ang)*spd*0.8 - rand(10,40); const life=rand(0.28, 0.55); pool.push(new Spark(this.x, this.y, vx, vy, rgb, life, 'crackle')); } return true; }
    draw(){ }
  }

  let last = 0;
  function loop(ts){ if(!last) last = ts; const dt = Math.min(0.033, (ts-last)/1000); last = ts; fadeScene();
    for(let i=rockets.length-1;i>=0;i--){ const r=rockets[i]; if(!r.update(dt)) rockets.splice(i,1); else r.draw(); }
    for(let i=emitters.length-1;i>=0;i--){ const e=emitters[i]; if(!e.update(dt)) emitters.splice(i,1); else e.draw(); }
    for(let i=pool.length-1;i>=0;i--){ const s=pool[i]; if(!s.update(dt)) pool.splice(i,1); else s.draw(); }
    for(let i=pearls.length-1;i>=0;i--){ const p=pearls[i]; if(!p.update(dt)) pearls.splice(i,1); else p.draw(); }
    for(let i=palms.length-1;i>=0;i--){ const pc=palms[i]; if(!pc.update(dt)) palms.splice(i,1); else pc.draw(); }
    for(let i=cseeds.length-1;i>=0;i--){ const cs=cseeds[i]; if(!cs.update(dt)) cseeds.splice(i,1); else cs.draw(); }
    if(params.auto && Math.random() < 0.012*params.density){ launchRandom(); }
    rafId = requestAnimationFrame(loop);
  }

  function start(opts){
    Object.assign(params, defaults, (opts||{}));
    ensureCanvas();
    last = 0; rafId && cancelAnimationFrame(rafId); rafId = requestAnimationFrame(loop);
  }
  function stop(){ if(rafId){ cancelAnimationFrame(rafId); rafId=null; } if(ctx){ ctx.clearRect(0,0,W,H); } pool.length=0; rockets.length=0; emitters.length=0; pearls.length=0; palms.length=0; cseeds.length=0; }
  function setZ(z){ if(canvas) canvas.style.zIndex = String(z); }
  function setOpacity(op){ if(canvas) canvas.style.opacity = String(op); }
  function setWind(w){ params.wind = Number(w)||0; }
  function setDensity(d){ params.density = Math.max(0, Math.min(1, Number(d)||0)); }

  window.fireworksBG = { start, stop, setZ, setOpacity, setWind, setDensity };
})();

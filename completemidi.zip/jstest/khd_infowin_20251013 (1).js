/* khd_infowin_20251013_v2.2b_mapperJ_catalog_fixA.js — Sem | 2025-10-13
 * Info window (v2.2b + MapperJ) — FIX A:
 *  - Basic SF info (Size/RIFF/Type/Banks) now fills even when sfont name is empty
 *    by falling back to sfSelected / __LAST_SF_NAME__/__LAST_SF_AB__.
 *  - Console/Song/About/Manual/Server unchanged. No alerts.
 */
(function(){
  if (window.__INFOWIN_V2_READY__) return; // same guard as your baseline
  window.__INFOWIN_V2_READY__ = true;

  /* ---------- Helpers ---------- */
  function esc(s){ return (s==null?'':String(s))
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function fmtBytes(n){ if(!isFinite(n)||n<=0) return '—'; const u=['B','KB','MB','GB']; let i=0; while(n>=1024 && i<u.length-1){ n/=1024; i++; } return (i===0? Math.round(n): n.toFixed(2))+' '+u[i]; }
  function fmtSecs(s){ if(!isFinite(s)||s<0) return '—'; const m=Math.floor(s/60), sec=Math.floor(s%60); return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`; }
  function nowTS(){ return new Date().toLocaleString(); }
  function setInfoStatus(msg){ const s=document.getElementById('infoStatus'); if (s) s.textContent = msg || ''; }

  /* ---------- Console capture ---------- */
  if (!window.__LOGBUF){
    const LOGBUF = [];
    function toText(args){ return Array.from(args).map(x=>{ try{ return (typeof x==='string')? x : JSON.stringify(x); }catch(_){ return String(x); } }).join(' '); }
    ['log','info','warn','error'].forEach(level=>{ const orig = console[level]; console[level] = function(){ try{ LOGBUF.push({ t: Date.now(), level, msg: toText(arguments) }); if (LOGBUF.length > 2000) LOGBUF.splice(0, LOGBUF.length - 2000); }catch(_){} try{ return orig.apply(console, arguments); }catch(_){} }; });
    window.__LOGBUF = LOGBUF;
  }
  const LOGBUF = window.__LOGBUF;

  /* ---------- MIDI helpers ---------- */
  function midiDurationSeconds(ab){ try{ if (!ab || typeof MIDIFile !== 'function') return null; const mf=new MIDIFile(ab); const evs=(mf.getMidiEvents?.()||mf.getEvents?.()||[]); let max=0; for (let i=0;i<evs.length;i++){ const p=evs[i]?.playTime; if (typeof p==='number' && p>max) max=p; } return max ? (max/1000) : null; }catch(_){ return null; } }

  function extractMIDIMeta(ab){ const meta={ header:{ppqn:null}, tempos:[], timesigs:[], keysigs:[], trackNames:[], copyright:[], markers:[], cuePoints:[], texts:[] };
    try{ if (!ab || typeof MIDIFile !== 'function') return meta; const mf=new MIDIFile(ab);
      try{ if (mf.header?.getTicksPerBeat) meta.header.ppqn = mf.header.getTicksPerBeat(); }catch(_){ }
      try{ (mf.getTempoEvents?.()||[]).forEach(e=>{ const bpm=e.bpm ?? (e.tempo? 60000000/e.tempo : null); if (bpm) meta.tempos.push({ bpm: Math.round(bpm*100)/100, playTime:(e.playTime||0)/1000 }); }); }catch(_){ }
      try{ (mf.getTimeSignatureEvents?.()||[]).forEach(e=>{ const num=e.timeSignature?.[0] ?? e.param1 ?? null; const denPow=e.timeSignature?.[1] ?? e.param2 ?? null; const den=denPow!=null? (1<<denPow) : null; meta.timesigs.push({ num, den, playTime:(e.playTime||0)/1000 }); }); }catch(_){ }
      const evs=(mf.getMidiEvents?.()||mf.getEvents?.()||[]);
      for (let i=0;i<evs.length;i++){
        const e=evs[i]||{}; const st=e.subtype; const txt=(typeof e.text==='string')? e.text.trim(): null; const pt=(e.playTime||0)/1000;
        if (st==='trackName' && txt) meta.trackNames.push(txt);
        else if ((st==='text'||st==='lyrics') && txt) meta.texts.push(txt);
        else if (st==='copyrightNotice' && txt) meta.copyright.push(txt);
        else if (st==='marker' && txt) meta.markers.push(txt);
        else if (st==='cuePoint' && txt) meta.cuePoints.push(txt);
        else if (st==='keySignature'){
          const sf=(e.scale ?? e.key ?? e.param1 ?? 0), mi=(e.minor ?? e.param2 ?? 0);
          let name='Key'; try{ const names=['Cb','Gb','Db','Ab','Eb','Bb','F','C','G','D','A','E','B','F#','C#']; const idx=sf+7; name=(names[idx]||'C') + (mi?'m':''); }catch(_){ }
          meta.keysigs.push({ sf, mi, text:name, playTime:pt });
        }
      }
    }catch(_){ }
    return meta; }

  function currentChannelPatches(){ const rows=[]; try{ if (!window.__MIX16 || typeof __MIX16.getPatch!=='function') return rows; for (let ch=0; ch<16; ch++){ const p=__MIX16.getPatch(ch)||{}; const msb=p.bankMSB ?? 0; const lsb=p.bankLSB ?? 0; const prog=p.program ?? 0; const name=(p.name||p.programName||''); rows.push({ ch, msb, lsb, prog, name }); } }catch(_){ } return rows; }

  /* ---------- SF2/3 parser (PHDR catalog) ---------- */
  function toArrayBufferSync(x){ try{ if (!x) return null; if (x instanceof ArrayBuffer) return x; if (ArrayBuffer.isView(x)) return x.buffer.slice(x.byteOffset||0, (x.byteOffset||0) + x.byteLength); return null; }catch(_){ return null; } }
  function parseSFInfo(ab){ const out={ riff:'', type:'', tags:{}, presets:[], banks:[], presetCount:0 }; if (!ab) return out; try{ const dv=new DataView(ab); const decA=new TextDecoder('ascii'); const decU=new TextDecoder('utf-8'); function str(off,len){ return decA.decode(new Uint8Array(ab,off,len)); } function u32(off){ return dv.getUint32(off,true); } const riff=str(0,4), type=str(8,4); out.riff=riff; out.type=type; let p=12; while(p+8<=dv.byteLength){ const id=str(p,4), len=u32(p+4), dataStart=p+8, dataEnd=dataStart+len; if (id==='LIST'){ const listType=str(dataStart,4); if (listType==='INFO'){ let q=dataStart+4; while(q+8<=dataEnd){ const sid=str(q,4), slen=u32(q+4), sStart=q+8, sEnd=sStart+slen; const raw=new Uint8Array(ab,sStart,slen); let val=''; try{ val=decU.decode(raw);}catch(_){ try{val=decA.decode(raw);}catch(_){val='';} } val=val.replace(/\u0000+$/,'').trim(); out.tags[sid]=val; q=sEnd+(slen%2); } } } else if (id==='pdta'){ let q=dataStart; while(q+8<=dataEnd){ const sid=str(q,4), slen=u32(q+4), sStart=q+8, sEnd=sStart+slen; if (sid==='phdr'){ const rec=38, count=Math.floor(slen/rec); for (let i=0;i<count;i++){ const base=sStart+i*rec; const name=str(base,20).replace(/\u0000+$/,'').trim(); const wPreset=dv.getUint16(base+20,true); const wBank=dv.getUint16(base+22,true); out.presets.push({ name, preset:wPreset, bank:wBank }); } if (out.presets.length>0) out.presets.pop(); out.presetCount=out.presets.length; const uniq=new Set(out.presets.map(p=>p.bank)); out.banks=Array.from(uniq).sort((a,b)=>a-b); } q=sEnd; } } p = dataEnd + (len % 2); } }catch(_){ } return out; }

  /* ---------- HTML builders ---------- */
  function htmlConsole(){
    const latestFirst = (LOGBUF||[]).slice(-600).reverse();
    const rows = latestFirst.map(e=>{ const t=new Date(e.t).toLocaleTimeString(); return `<div class="log-row ${esc(e.level)}"><span class="ts">${esc(t)}</span><span class="lvl">${esc(e.level.toUpperCase())}</span><span class="msg">${esc(e.msg)}</span></div>`; }).join('');
    return `
      <div class="section">
        <div class="tools">
          <input id="infCmd" class="search" placeholder="Type a JS expression and press Enter…" />
          <button id="infRun" class="small">Run</button>
          <button id="infLogClear" class="small">Clear</button>
          <button id="infLogCopy"  class="small">Copy</button>
        </div>
        <div id="infLogBox" class="log-box">${rows || '<div class="log-row"><span class="msg">No logs yet</span></div>'}</div>
      </div>`;
  }

  function lyricsTextFromJSON(j){ try{ if (!j || !Array.isArray(j.lines)) return ''; return j.lines.map(L => (Array.isArray(L.words)? L.words.map(w=>w.w).join('') : '')).join('\n').trim(); }catch(_){ return ''; } }

  function htmlSong(){ const rel=window.currentSong||''; const name=window.lastPlayed?.name || (rel ? rel.split('/').pop() : ''); const size=(window.lastMIDIBuf&&window.lastMIDIBuf.byteLength)||0; const dur=midiDurationSeconds(window.lastMIDIBuf); const state=window.isPlaying? 'Playing':'Idle'; const meta=extractMIDIMeta(window.lastMIDIBuf); const patches=currentChannelPatches();
    const tempoStr=(meta.tempos||[]).map(t=>`${t.bpm} BPM @${fmtSecs(t.playTime)}`).join(', ')||'—'; const tsStr=(meta.timesigs||[]).map(t=>`${t.num}/${t.den} @${fmtSecs(t.playTime)}`).join(', ')||'—'; const ksStr=(meta.keysigs||[]).map(k=>`${k.text} @${fmtSecs(k.playTime)}`).join(', ')||'—';
    const tn=(meta.trackNames||[]).length? meta.trackNames.map(t=>`<li>${esc(t)}</li>`).join('') : '<li>—</li>'; const cp=(meta.copyright||[]).length? meta.copyright.map(t=>`<li>${esc(t)}</li>`).join('') : '<li>—</li>'; const mk=(meta.markers||[]).length? meta.markers.map(t=>`<li>${esc(t)}</li>`).join('') : '<li>—</li>'; const cues=(meta.cuePoints||[]).length? meta.cuePoints.map(t=>`<li>${esc(t)}</li>`).join('') : '<li>—</li>';
    const lyrText=lyricsTextFromJSON(window.lastLyrics); const lyrHTML=lyrText? `<pre class="lyrics-pre">${esc(lyrText)}</pre>` : '<div class="kv"><span class="v">No lyrics</span></div>';
    const patchRows=patches.map(p=>{ const ch=p.ch+1; const label=(p.name||'').trim(); return `<div class="rowp"><span class="c">CH${ch}</span><span class="b">${p.msb}/${p.lsb}</span><span class="p">${p.prog}</span><span class="n">${esc(label||'—')}</span></div>`; }).join('');
    return `
      <div class="kv"><span class="k">Title</span><span class="v">${esc(name)}</span></div>
      <div class="kv"><span class="k">Path</span><span class="v">${esc(rel)}</span></div>
      <div class="kv"><span class="k">Size</span><span class="v">${fmtBytes(size)}</span></div>
      <div class="kv"><span class="k">Duration</span><span class="v">${fmtSecs(dur)}</span></div>
      <div class="kv"><span class="k">State</span><span class="v">${esc(state)}</span></div>
      <h5>MIDI Meta</h5>
      <div class="kv"><span class="k">PPQN</span><span class="v">${meta.header.ppqn ?? '—'}</span></div>
      <div class="kv"><span class="k">Tempo</span><span class="v">${esc(tempoStr)}</span></div>
      <div class="kv"><span class="k">Time Sig</span><span class="v">${esc(tsStr)}</span></div>
      <div class="kv"><span class="k">Key Sig</span><span class="v">${esc(ksStr)}</span></div>
      <div class="kv"><span class="k">Tracks</span><span class="v"><ul class="bul">${tn}</ul></span></div>
      <div class="kv"><span class="k">Copyright</span><span class="v"><ul class="bul">${cp}</ul></span></div>
      <div class="kv"><span class="k">Markers</span><span class="v"><ul class="bul">${mk}</ul></span></div>
      <div class="kv"><span class="k">Cue Points</span><span class="v"><ul class="bul">${cues}</ul></span></div>
      <h5>Channel Patches (Live)</h5>
      <div class="patch-grid">
        <div class="hdr"><span class="c">Ch</span><span class="b">MSB/LSB</span><span class="p">Prog</span><span class="n">Name</span></div>
        ${patchRows}
      </div>
      <h5>Lyrics (Full)</h5>
      ${lyrHTML}
    `;
  }

  /* ---------- Mapper J (SimpleMapperCatalog) integration + FIX ---------- */
  function getMapperCatalogList(){
    try{
      const M = window.SimpleMapperCatalog || window.SimpleMapper || window.MapperJ || null;
      if (!M) return null;
      const list = (typeof M.getInstrumentList==='function') ? M.getInstrumentList() :
                   (typeof M.list==='function') ? M.list() : [];
      if (!Array.isArray(list) || !list.length) return [];
      return list.map(it=>({
        name: (it.name||'').trim(),
        msb: it.bankMSB|0,
        lsb: it.bankLSB|0,
        prog: it.program|0,
        sfont: (it.sfont||'').trim()
      })).filter(r=> r.name && r.msb>=0 && r.lsb>=0 && r.prog>=0);
    }catch(_){ return null; }
  }

  function groupBySFont(rows){
    const groups = new Map();
    rows.forEach(r=>{ const key=((r.sfont||'').trim()) || '(unnamed)'; if (!groups.has(key)) groups.set(key, []); groups.get(key).push(r); });
    return groups;
  }

  function toArrayBufFromCacheKey(key){ try{ const cache=window.sfCache||{}; const raw=cache[key]; return toArrayBufferSync(raw); }catch(_){ return null; } }
  function findSFCacheKeyLike(name){ try{ const cache=window.sfCache||{}; const keys=Object.keys(cache); const n=(name||'').toLowerCase(); for(let i=0;i<keys.length;i++){ if(keys[i].toLowerCase()===n) return keys[i]; } for(let i=0;i<keys.length;i++){ if(keys[i].toLowerCase().includes(n)) return keys[i]; } }catch(_){ } return null; }
  function resolveSFSource(prefName){
    // Try matching sfCache by name; else fall back to sfSelected; else __LAST_SF_AB__
    let rel = prefName || '';
    let ab = null;
    const byName = prefName ? findSFCacheKeyLike(prefName) : null;
    if (byName){ rel = byName; ab = toArrayBufFromCacheKey(byName); }
    if (!ab){ const sel=window.sfSelected||''; if (sel){ rel = sel; ab = toArrayBufFromCacheKey(sel); } }
    if (!ab && window.__LAST_SF_AB__){ rel = window.__LAST_SF_NAME__ || rel; ab = toArrayBufferSync(window.__LAST_SF_AB__); }
    return { ab, rel };
  }

  function buildSectionFromMapper(name, rows){
    // Display name fallback
    let displayName = (name && name.trim()) || (window.__LAST_SF_NAME__||window.sfSelected||'(unnamed)');
    const src = resolveSFSource(name);
    let riff='—', type='—', size=0, banks='—';
    try{ if (src.ab){ size=src.ab.byteLength; const info=parseSFInfo(src.ab); riff=info.riff||riff; type=info.type||type; banks=(info.banks||[]).join(', ')||banks; } }catch(_){ }

    const grid = rows.length
      ? (`<div class="sf-grid">
            <div class="hdr"><span class="b">MSB</span><span class="b">LSB</span><span class="p">Prog</span><span class="n">Name</span></div>
            ${rows.map(r=>`<div class="sfp ${((r.msb*128+r.lsb)===128)?'drum':''}"><span class="b">${r.msb}</span><span class="b">${r.lsb}</span><span class="p">${r.prog}</span><span class="n">${esc(r.name)}</span></div>`).join('')}
         </div>`)
      : '<div class="small" style="opacity:.8">No presets found</div>';

    return `
      <h5 style="margin-top:14px">${esc(displayName||'(unnamed)')}</h5>
      <div class="kv"><span class="k">Size</span><span class="v">${fmtBytes(size)}</span></div>
      <div class="kv"><span class="k">RIFF</span><span class="v">${esc(riff)}</span></div>
      <div class="kv"><span class="k">Type</span><span class="v">${esc(type)}</span></div>
      <div class="kv"><span class="k">Presets</span><span class="v">${rows.length}</span></div>
      <div class="kv"><span class="k">Banks</span><span class="v">${esc(banks)}</span></div>
      <h5>Instrument Catalog (MSB / LSB / Program)</h5>
      ${grid}`;
  }

  function htmlSFCatalog(){
    const list = getMapperCatalogList() || [];
    if (!list.length){
      return '<div class="small" style="opacity:.8">No MapperJ catalog available. Load SF or ensure SimpleMapperCatalog is active.</div>';
    }
    const groups = groupBySFont(list);
    let order = Array.from(groups.keys());
    const sel = (window.sfSelected||'').trim().toLowerCase();
    order = order.sort((a,b)=> (a.toLowerCase()===sel?-1 : b.toLowerCase()===sel?1 : a.localeCompare(b)));
    const sections = order.map(name=> buildSectionFromMapper(name, groups.get(name)||[]));
    return sections.join('\n');
  }

  /* ---------- Panel shell ---------- */
  function ensurePanel(){ if (document.getElementById('infoPanel')) return; const sec=document.createElement('section'); sec.className='panel win'; sec.id='infoPanel'; sec.innerHTML=`
      <h4 class="drag"><span>Info</span>
        <span><button class="close" data-close="info">×</button></span>
      </h4>
      <div class="list">
        <div class="tabs">
          <button class="tab small" data-tab="console">Console</button>
          <button class="tab small" data-tab="song">Song</button>
          <button class="tab small" data-tab="soundfont">SoundFont</button>
          <button class="tab small" data-tab="server">Server</button>
          <button class="tab small" data-tab="about">About</button>
          <button class="tab small" data-tab="manual">Manual</button>
          <span class="small" style="margin-left:auto" id="infoStatus"></span>
        </div>
        <div class="info-pane" id="pane-console"></div>
        <div class="info-pane" id="pane-song"></div>
        <div class="info-pane" id="pane-soundfont"></div>
        <div class="info-pane" id="pane-server"></div>
        <div class="info-pane" id="pane-about"></div>
        <div class="info-pane" id="pane-manual"></div>
      </div>`; document.body.appendChild(sec);
    const css=document.createElement('style'); css.textContent=`
      #infoPanel .tabs{ display:flex; gap:6px; padding:8px; border-bottom:1px solid rgba(255,255,255,.06); background:rgba(18,18,18,.6) }
      #infoPanel .tab.active{ outline:2px solid var(--accent); outline-offset:2px }
      #infoPanel .info-pane{ display:none; padding:8px 12px }
      #infoPanel .info-pane.active{ display:block }
      #infoPanel .kv{ display:grid; grid-template-columns: 160px 1fr; gap:8px; padding:4px 0; border-bottom:1px dashed rgba(255,255,255,.08) }
      #infoPanel .kv .k{ color:#b7c3cf }
      #infoPanel .kv .v{ color:#dfe3e8 }
      #infoPanel h5{ margin:12px 0 6px 0; font-weight:700; color:#cfe7ff }
      #infoPanel .bul{ margin:6px 0 0 16px }
      #infoPanel .log-box{ font:12px/1.35 monospace; background:#0f1418; border:1px solid #223; border-radius:8px; padding:8px; max-height:36vh; overflow:auto }
      #infoPanel .log-row{ display:grid; grid-template-columns: 90px 70px 1fr; gap:8px; padding:2px 0; }
      #infoPanel .log-row .ts{ color:#9fb3c7 }
      #infoPanel .log-row .lvl{ color:#cfd7df }
      #infoPanel .log-row .msg{ color:#e7edf3; white-space:pre-wrap; }
      #infoPanel .log-row.warn .lvl{ color:#ffd166 }
      #infoPanel .log-row.error .lvl{ color:#ff6b6b }
      #infoPanel .tools{ display:flex; gap:6px; margin-bottom:6px; align-items:center }
      #infoPanel .tools .search{ flex:1; background:#101417; color:var(--fg); border:1px solid rgba(255,255,255,.15); padding:6px 10px; border-radius:8px; outline:none; min-width:120px }
      #infoPanel .lyrics-pre{ white-space:pre-wrap; background:#0f1418; border:1px solid #223; border-radius:8px; padding:8px; max-height:36vh; overflow:auto }
      #infoPanel .patch-grid .hdr, #infoPanel .patch-grid .rowp{ display:grid; grid-template-columns: 48px 90px 60px 1fr; gap:8px; padding:2px 0; }
      #infoPanel .patch-grid .hdr{ color:#cfe7ff; border-bottom:1px dashed rgba(255,255,255,.12); margin-bottom:4px }
      #infoPanel .sf-grid .hdr, #infoPanel .sf-grid .sfp{ display:grid; grid-template-columns: 64px 64px 64px 1fr; gap:8px; padding:2px 0; }
      #infoPanel .sf-grid .hdr{ color:#cfe7ff; border-bottom:1px dashed rgba(255,255,255,.12); margin-bottom:4px }
      #infoPanel .sf-grid .sfp.drum .n{ color:#ffd166 }`; document.head.appendChild(css);
  }

  function renderPane(id, html){ const el=document.getElementById(id); if (!el) return; el.innerHTML=html; if (id==='pane-console') bindConsoleTools(); }

  /* ---------- Console REPL tools (NO alerts) ---------- */
  function bindConsoleTools(){
    const clearBtn=document.getElementById('infLogClear');
    const copyBtn =document.getElementById('infLogCopy');
    const runBtn  =document.getElementById('infRun');
    const cmdInp  =document.getElementById('infCmd');
    const histKey ='inf_cmd_hist';
    let hist = []; try{ hist = JSON.parse(localStorage.getItem(histKey)||'[]'); }catch(_){ }
    let hIndex = hist.length;

    function pushLog(level,msg){ try{ LOGBUF.push({ t: Date.now(), level, msg }); if (LOGBUF.length>2000) LOGBUF.splice(0, LOGBUF.length-2000); }catch(_){ } renderPane('pane-console', htmlConsole()); }

    function runCmd(){ const code=(cmdInp?.value||'').trim(); if (!code) return; hist.push(code); hIndex=hist.length; try{ localStorage.setItem(histKey, JSON.stringify(hist).slice(0,20000)); }catch(_){ }
      try{
        const result = (0,eval)(code);
        if (result && typeof result.then==='function'){
          pushLog('info', `▶ ${code}`);
          result.then(v=> pushLog('log', `✓ ${code} → ${JSON.stringify(v)}`))
                .catch(e=> pushLog('error', `✗ ${code} → ${e?.message||String(e)}`));
        } else {
          pushLog('log', `▶ ${code} → ${JSON.stringify(result)}`);
        }
      }catch(e){ pushLog('error', `✗ ${code} → ${e?.message||String(e)}`); }
      cmdInp.value=''; cmdInp.focus(); setInfoStatus('Ran command at '+nowTS());
    }

    cmdInp && cmdInp.addEventListener('keydown', (ev)=>{
      if (ev.key==='Enter'){ ev.preventDefault(); runCmd(); }
      else if (ev.key==='ArrowUp'){ ev.preventDefault(); if (hIndex>0){ hIndex--; cmdInp.value=hist[hIndex]||''; cmdInp.selectionStart=cmdInp.selectionEnd=cmdInp.value.length; } }
      else if (ev.key==='ArrowDown'){ ev.preventDefault(); if (hIndex<hist.length){ hIndex++; cmdInp.value=hist[hIndex]||''; cmdInp.selectionStart=cmdInp.selectionEnd=cmdInp.value.length; } }
    });
    runBtn && runBtn.addEventListener('click', runCmd);

    clearBtn && clearBtn.addEventListener('click', ()=>{ LOGBUF.length=0; renderPane('pane-console', htmlConsole()); setInfoStatus('Console cleared at '+nowTS()); });
    copyBtn && copyBtn.addEventListener('click', ()=>{ try{ const text=(LOGBUF||[]).map(e=>`[${new Date(e.t).toISOString()}] ${e.level.toUpperCase()}: ${e.msg}`).join('\n'); navigator.clipboard?.writeText(text).then(()=> setInfoStatus('Console copied at '+nowTS())).catch(()=> setInfoStatus('Clipboard copy failed at '+nowTS())); }catch(_){ setInfoStatus('Clipboard copy failed at '+nowTS()); } });
  }

  /* ---------- Other panes ---------- */
  function htmlServer(){ const S=window.SERVER_INFO||{}; const url=location.href; return `
      <div class="kv"><span class="k">URL</span><span class="v">${esc(url)}</span></div>
      <div class="kv"><span class="k">Host</span><span class="v">${esc(location.host)}</span></div>
      <div class="kv"><span class="k">Protocol</span><span class="v">${esc(location.protocol)}</span></div>
      <div class="kv"><span class="k">PHP</span><span class="v">${esc(S.php_version||'—')}</span></div>
      <div class="kv"><span class="k">Server</span><span class="v">${esc(S.server_software||'—')}</span></div>
      <div class="kv"><span class="k">OS</span><span class="v">${esc(S.os||'—')}</span></div>
      <div class="kv"><span class="k">Timezone</span><span class="v">${esc(S.timezone||'—')}</span></div>
      <div class="kv"><span class="k">Doc Root</span><span class="v">${esc(S.document_root||'—')}</span></div>
      <div class="kv"><span class="k">Script</span><span class="v">${esc(S.script||'—')}</span></div>
      <div class="kv"><span class="k">upload_max_filesize</span><span class="v">${esc(S.upload_max_filesize||'—')}</span></div>
      <div class="kv"><span class="k">post_max_size</span><span class="v">${esc(S.post_max_size||'—')}</span></div>
      <div class="kv"><span class="k">memory_limit</span><span class="v">${esc(S.memory_limit||'—')}</span></div>
      <div class="kv"><span class="k">max_execution_time</span><span class="v">${esc(S.max_execution_time||'—')}</span></div>`; }

  function htmlAbout(){ const v=window.APP_VERSION||'—'; const libs=[ {name:'libfluidsynth (WASM)', src:'libfluidsynth-2.4.6-with-libsndfile.js'}, {name:'JS Synthesizer', src:'js-synthesizer.min.js'}, {name:'MIDIFile', src:'MIDIFile.js'}, {name:'SimpleMapper + MIX16', src:'simple_mapper_catalog_bundle_v1.1.4.js / mixer16_patch_v4.2.9f'} ]; const rows=libs.map(l=>`<div class="kv"><span class="k">${esc(l.name)}</span><span class="v">${esc(l.src)}</span></div>`).join(''); return `
      <div class="kv"><span class="k">Program</span><span class="v">KaraokeHD Player</span></div>
      <div class="kv"><span class="k">Version</span><span class="v">${esc(v)}</span></div>
      <div class="kv"><span class="k">Build</span><span class="v">${esc(nowTS())}</span></div>
      <h5>Modules</h5>
      ${rows}
      <div class="kv"><span class="v">© Sem Sabiduria. For internal use only.</span></div>`; }

  function htmlManual(){ return `
      <h5>Shortcuts</h5>
      <ul class="bul">
        <li><b>Space</b> — Play / Stop</li>
        <li><b>F</b> — Fullscreen toggle</li>
        <li><b>L</b> — Lyrics window toggle</li>
        <li><b>Alt+Click</b> a song — Stop current and play immediately</li>
        <li><b>Shift+Click</b> a song — Queue next (ahead of others)</li>
      </ul>
      <h5>Tips</h5>
      <ul class="bul">
        <li>Control Center → <b>SF Policy</b> chooses when SF change applies.</li>
        <li>Lyrics <b>Glow</b> and <b>AutoHide</b> are in the window bar & CC.</li>
        <li>Use the micro‑dock to pin lyrics, open panels, or access CC quickly.</li>
        <li>Backgrounds panel: shuffle videos/images, gradients, or solid colors.</li>
      </ul>`; }

  /* ---------- Tabs + WM + Dock ---------- */
  function activate(tab){ ['console','song','soundfont','server','about','manual'].forEach(t=>{ const pane=document.getElementById('pane-'+t); const btn=document.querySelector('#infoPanel .tab[data-tab="'+t+'"]'); pane&&pane.classList.toggle('active', t===tab); btn&&btn.classList.toggle('active', t===tab); }); }
  function refreshAll(){ renderPane('pane-console', htmlConsole()); renderPane('pane-song', htmlSong()); renderPane('pane-soundfont', htmlSFCatalog()); renderPane('pane-server', htmlServer()); renderPane('pane-about', htmlAbout()); renderPane('pane-manual', htmlManual()); setInfoStatus('Updated: '+nowTS()); }
  function bindTabs(){ const tabs=document.querySelectorAll('#infoPanel .tab'); tabs.forEach(b=> b.addEventListener('click', function(){ activate(b.getAttribute('data-tab')); refreshAll(); })); activate('song'); }
  function bindClose(){ document.querySelector('#infoPanel .close')?.addEventListener('click', function(){ document.getElementById('infoPanel')?.classList.remove('visible'); }); }
  function bindWM(){ if (!window.WM) return; const el=document.getElementById('infoPanel'); window.WM.info={ element: el, show(){ el.classList.add('visible'); refreshAll(); window.ZStack?.bring?.(el); }, hide(){ el.classList.remove('visible'); }, toggle(){ el.classList.toggle('visible'); if (el.classList.contains('visible')){ refreshAll(); window.ZStack?.bring?.(el); } } }; }
  function extendMicroDock(){ const menu=document.getElementById('mdPanelMenu'); if (!menu || menu.querySelector('[data-open="info"]')) return; const btn=document.createElement('button'); btn.className='md-item'; btn.setAttribute('data-open','info'); btn.textContent='Info'; btn.addEventListener('click', function(){ try{ WM?.info?.show?.(); }catch(_){ } menu.classList.remove('open'); document.getElementById('mdPanel')?.classList.remove('active'); }); menu.appendChild(btn); }

  /* ---------- Init ---------- */
  let logTick=0;
  function init(){ ensurePanel(); bindWM(); extendMicroDock(); bindTabs(); bindClose(); refreshAll(); setInterval(()=>{ const panelVisible=document.getElementById('infoPanel')?.classList.contains('visible'); const consoleActive=document.getElementById('pane-console')?.classList.contains('active'); if (!panelVisible || !consoleActive) return; const nowLen=(LOGBUF||[]).length; if (nowLen!==logTick){ logTick=nowLen; renderPane('pane-console', htmlConsole()); } }, 800); }
  if (document.readyState==='complete' || document.readyState==='interactive'){ setTimeout(init, 0); } else { document.addEventListener('DOMContentLoaded', init); }
})();

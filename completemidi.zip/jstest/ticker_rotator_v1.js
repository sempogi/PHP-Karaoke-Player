/*! Ticker Rotator v1.0.0 — Sem • 2025-10-16
 * Make the ticker less boring by alternating (or randomizing) between:
 *   • Song TRIVIA (from Song Info data available on page/globals/cache)
 *   • Upcoming QUEUE items (next tracks in playlist)
 *
 * Non-invasive: adds its own span inside the ticker area; does not change Title Splash.
 * Load AFTER your current Title/Ticker scripts.
 */
(function(window, document){
  'use strict';
  if (window.TickerRotator) return; // idempotent

  var CFG = {
    mode: (localStorage.getItem('tickerRotMode')||'alternate'), // 'alternate' | 'random'
    intervalMs: parseInt(localStorage.getItem('tickerRotInterval')||'6000',10) || 6000,
    containerSel: localStorage.getItem('tickerRotContainer') || '#tickerInfo',
    titleSel: localStorage.getItem('tickerRotTitle') || '#tickerTitle, .ticker .title',
    playlistSel: localStorage.getItem('tickerRotPlaylist') || '#plBody, #playlist, .playlist, #playlistTable',
    maxQueueItems: parseInt(localStorage.getItem('tickerRotMaxQueue')||'5',10) || 5,
    enable: (localStorage.getItem('tickerRotEnable')||'on')==='on',
    debug: (localStorage.getItem('tickerRotDebug')||'off')==='on'
  };
  function d(){ if (!CFG.debug) return; try{ console.log.apply(console, ['[TickerRot]'].concat([].slice.call(arguments))); }catch(_){} }

  function $(sel){ try { return document.querySelector(sel); } catch(_) { return null; } }
  function $firstOfList(listSel){ var sel=String(listSel||'').split(','); for (var i=0;i<sel.length;i++){ var el=$(sel[i].trim()); if (el) return el; } return null; }

  // Ensure a host span we can control (separate from the main title)
  function ensureHost(){
    var cont = $firstOfList(CFG.containerSel);
    if (!cont) { d('container not found', CFG.containerSel); return null; }
    var host = document.getElementById('tickerRotatorSpan');
    if (!host){ host = document.createElement('span'); host.id = 'tickerRotatorSpan'; host.className = 'ticker-rotator'; host.style.marginLeft='12px'; host.style.opacity='0.0'; host.style.transition='opacity .35s ease'; cont.appendChild(host); }
    return host;
  }

  // Try to get the default title element (we keep it but we do not overwrite permanently)
  function getTitleEl(){ return $firstOfList(CFG.titleSel); }

  // Build TRIVIA from Song Info
  function getSongInfoCurrent(){ try { if (window.SongInfo && typeof SongInfo.getCurrent==='function') return SongInfo.getCurrent()||null; } catch(_){}
    try { if (window.SongInfo && SongInfo.current) return SongInfo.current; } catch(_){}
    // Weak fallback: scan a few known globals
    var c={}; try{ c.title = window.nowTitle||window.nowPlayingTitle||''; }catch(_){}
    try{ c.artist = window.nowArtist||window.nowPlayingArtist||''; }catch(_){}
    try{ c.album = window.nowAlbum || ''; }catch(_){}
    try{ c.year = window.nowYear || ''; }catch(_){}
    try{ c.genre = window.nowGenre || ''; }catch(_){}
    try{ c.label = window.nowLabel || ''; }catch(_){}
    try{ c.country = window.nowCountry || ''; }catch(_){}
    return c; }

  function compact(a){ return (a||[]).filter(function(x){ return !!x && String(x).trim().length>0; }); }
  function uniq(a){ var s=new Set(), out=[]; for (var i=0;i<a.length;i++){ var v=String(a[i]); if (!s.has(v)){ s.add(v); out.push(v); } } return out; }

  function buildTriviaLines(){
    var si = getSongInfoCurrent() || {};
    var lines = [];
    // iTunes-like
    try{ var rel = si.releaseDate || si.release_date || si.date; if (rel) { var y = (String(rel).match(/\d{4}/)||[])[0]; if (y) lines.push('Released '+y); } }catch(_){}
    try{ if (si.album || si.collectionName) lines.push('Album: '+(si.album||si.collectionName)); }catch(_){}
    try{ if (si.label) lines.push('Label: '+si.label); }catch(_){}
    try{ if (si.country || si.countryCode) lines.push('Country: '+(si.country||si.countryCode)); }catch(_){}
    try{ if (si.genre || si.primaryGenreName) lines.push('Genre: '+(si.genre||si.primaryGenreName)); }catch(_){}
    try{ if (si.trackNumber && si.trackCount) lines.push('Track '+si.trackNumber+' of '+si.trackCount); else if (si.trackNumber) lines.push('Track '+si.trackNumber); }catch(_){}
    try{ if (si.bpm || si.tempo) lines.push('Tempo: '+(si.bpm||si.tempo)+' BPM'); }catch(_){}
    try{ if (si.key) lines.push('Key: '+si.key); }catch(_){}
    try{ if (si.mbLabel || si.mb_label) lines.push('Label: '+(si.mbLabel||si.mb_label)); }catch(_){}
    try{ if (si.mbReleaseCountry) lines.push('Release Country: '+si.mbReleaseCountry); }catch(_){}
    try{ if (si.mbCatalog || si.catalogNumber) lines.push('Catalog: '+(si.mbCatalog||si.catalogNumber)); }catch(_){}
    lines = uniq(compact(lines));
    if (!lines.length) lines = ['Enjoy the music!', 'Now Playing', '—'];
    return lines;
  }

  // Build QUEUE list from playlist DOM
  function buildQueueLines(){
    var root = $firstOfList(CFG.playlistSel);
    if (!root) { d('playlist not found'); return []; }
    // try common patterns: rows with [data-idx], or li, or tr
    var rows = [].slice.call(root.querySelectorAll('[data-idx], li, tr, .row, .item'));
    if (!rows.length) return [];
    // detect current and get next N
    var idx = -1;
    for (var i=0;i<rows.length;i++){
      var r=rows[i]; if (r.matches && (r.matches('.playing, .current, .on') || r.getAttribute('aria-current')==='true')) { idx=i; break; }
    }
    var start = (idx>=0? idx+1 : 0);
    var end = Math.min(rows.length, start + CFG.maxQueueItems);
    var out=[];
    for (var j=start;j<end;j++){
      var r=rows[j]; var t='';
      // extract text: prefer [data-title],[data-artist] or inner text pieces
      var ti = r.getAttribute && r.getAttribute('data-title');
      var ar = r.getAttribute && r.getAttribute('data-artist');
      if (!ti){ var el = r.querySelector && (r.querySelector('.title,.t,.name') || r.querySelector('td:nth-child(1)')); ti = el && (el.textContent||''); }
      if (!ar){ var el2 = r.querySelector && (r.querySelector('.artist,.a') || r.querySelector('td:nth-child(2)')); ar = el2 && (el2.textContent||''); }
      t = (ti?ti.trim():'') + (ar?(' — '+ar.trim()):'');
      if (t) out.push('Next: '+t);
    }
    return out;
  }

  // Rotator engine
  var state = { list:[], i:0, timer:0, lastKind:'' };

  function rebuild(){
    var trivia = buildTriviaLines();
    var queue  = buildQueueLines();
    var merged = [];
    if (CFG.mode==='alternate'){
      var a=Math.max(trivia.length, queue.length);
      for (var k=0;k<a;k++){ if (trivia[k]) merged.push({kind:'TRIVIA', text:trivia[k]}); if (queue[k]) merged.push({kind:'QUEUE', text:queue[k]}); }
    } else { // random
      merged = trivia.map(function(t){return {kind:'TRIVIA', text:t};}).concat(queue.map(function(q){return {kind:'QUEUE', text:q};}));
      // shuffle
      for (var m=merged.length-1; m>0; m--){ var r=Math.floor(Math.random()*(m+1)); var tmp=merged[m]; merged[m]=merged[r]; merged[r]=tmp; }
    }
    if (!merged.length) merged=[{kind:'INFO', text:'Ready.'}];
    state.list = merged; state.i=0; d('rebuilt', merged);
  }

  function step(){ if (!CFG.enable) return; var host=ensureHost(); if (!host) return;
    if (!state.list.length) rebuild();
    var item = state.list[state.i % state.list.length];
    host.textContent = item.text;
    host.style.opacity = '1.0';
    state.i++;
    clearTimeout(state.timer);
    state.timer = setTimeout(step, CFG.intervalMs);
  }

  function restart(){ clearTimeout(state.timer); state.timer=0; rebuild(); step(); }

  // Hooks: rebuild on new song
  (function hook() {
    if (window.StatusBus && typeof StatusBus.on==='function'){
      StatusBus.on(function(ev){ try{ if (String(ev.msg)==='PLAYING') restart(); }catch(_){ } });
    }
    // Also wrap setNowPlaying/updateTicker lightly to rebuild
    function wrap(name){ var fn=window[name]; if (typeof fn!=='function' || fn.__rot) return; window[name]=function(){ try{ var r=fn.apply(this, arguments); restart(); return r; }catch(_){ return fn.apply(this, arguments);} }; window[name].__rot=1; }
    wrap('setNowPlaying'); wrap('updateTicker');
  })();

  // Public API
  window.TickerRotator = {
    on : function(){ CFG.enable=true; localStorage.setItem('tickerRotEnable','on'); restart(); },
    off: function(){ CFG.enable=false; localStorage.setItem('tickerRotEnable','off'); clearTimeout(state.timer); var h=ensureHost(); if (h) h.style.opacity='0.0'; },
    mode: function(m){ if (!m) return CFG.mode; CFG.mode = (m==='random'?'random':'alternate'); localStorage.setItem('tickerRotMode', CFG.mode); restart(); },
    interval: function(ms){ if (!ms) return CFG.intervalMs; CFG.intervalMs = Math.max(1500, parseInt(ms,10)||6000); localStorage.setItem('tickerRotInterval', String(CFG.intervalMs)); restart(); },
    setSelectors: function(o){ if (!o) return; if (o.container){ CFG.containerSel=o.container; localStorage.setItem('tickerRotContainer', o.container);} if (o.title){ CFG.titleSel=o.title; localStorage.setItem('tickerRotTitle', o.title);} if (o.playlist){ CFG.playlistSel=o.playlist; localStorage.setItem('tickerRotPlaylist', o.playlist);} restart(); },
    setMaxQueue: function(n){ CFG.maxQueueItems = Math.max(1, parseInt(n,10)||5); localStorage.setItem('tickerRotMaxQueue', String(CFG.maxQueueItems)); restart(); },
    debug: function(on){ CFG.debug=!!on; localStorage.setItem('tickerRotDebug', on?'on':'off'); },
    rebuild: rebuild,
    restart: restart
  };

  // Bootstrap after DOM is ready
  function start(){ if (!CFG.enable) { d('disabled'); return; } restart(); }
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', start, {once:true}); else start();

})(window, document);

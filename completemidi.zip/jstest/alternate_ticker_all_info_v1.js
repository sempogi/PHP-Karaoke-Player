/*! Alternate Ticker — All Info v1.0.0 — Sem • 2025-10-16
 * Purpose: A simple, precise "alternate" ticker that cycles through ALL available
 *          song information (Artist, Title, Album, Year, Label, Country, Genre,
 *          Track X/Y, Tempo BPM, Key, Duration) and alternates with upcoming queue.
 *
 * Design goals:
 *  - Precise: No DOM guessing for song info if SongInfo.getCurrent() exists.
 *  - Minimal config: You only need to specify container and (optionally) playlist.
 *  - Fail-safe: If playlist selectors aren't provided/found, it still shows trivia.
 *  - Alternate mode only (no random). Clean text, no HTML injection.
 */
(function(window, document){
  'use strict';
  if (window.AltTickerAllInfo) return;

  var CFG = {
    container: '#tickerInfo',   // where to append the alt ticker span
    // Playlist (optional — required only if you want queue lines)
    playlist:  null,            // e.g., '#plBody'
    rowSelector: 'tr',          // e.g., 'li' for UL lists
    currentSelector: '.playing',// e.g., '.current' or '[aria-current="true"]'
    titleField: '.title',       // how to read title inside each row
    artistField: '.artist',     // how to read artist inside each row
    intervalMs: 6000,           // rotate every 6s (min 1500)
    maxQueue: 5                 // show up to N upcoming items
  };

  var ST = { host:null, list:[], i:0, timer:0 };

  // ---------- helpers ----------
  function $(sel){ try{ return document.querySelector(sel); }catch(_){ return null; } }
  function $in(root, sel){ try{ return root.querySelector(sel); }catch(_){ return null; } }
  function text(el){ return (el && el.textContent) ? el.textContent.trim() : ''; }
  function fmtDur(sec){ try{ sec=Math.max(0, Math.floor(sec||0)); var h=Math.floor(sec/3600), m=Math.floor((sec%3600)/60), s=sec%60; var mm=(h?String(m).padStart(2,'0'):String(m)); var ss=String(s).padStart(2,'0'); return h ? (h+':'+mm+':'+ss) : (mm+':'+ss); }catch(_){ return ''; } }

  function ensureHost(){ var cont=$(CFG.container); if (!cont) return null; if (ST.host && cont.contains(ST.host)) return ST.host; var span=document.createElement('span'); span.id='altTickerAllInfo'; span.className='alt-ticker-all'; span.style.marginLeft='12px'; span.style.opacity='0'; span.style.transition='opacity .35s ease'; cont.appendChild(span); ST.host=span; return span; }

  // ---------- Song Info (precise if SongInfo.getCurrent exists; else adapter from candy pill) ----------
  function getSongInfo(){
    try { if (window.SongInfo && typeof SongInfo.getCurrent==='function') { var si = SongInfo.getCurrent()||{}; return normalizeSI(si); } }catch(_){ }
    // Adapter from your candy pill (.si-info-pop) if present
    var node = document.querySelector('#tickerTrack .ticker-item.playing .si-info-pop')
           || document.querySelector('.ticker .ticker-item.playing .si-info-pop');
    var si={}; if (node){
      var txt = node.querySelector('.si-text')?.textContent?.trim() || '';
      var parts = txt.split(' • ');
      si.artist = parts[0]||''; si.album = parts[1]||''; si.year = parts[2]||'';
      var badges = node.querySelectorAll('.si-badge');
      si.label   = badges[0]?.textContent?.trim() || '';
      si.country = badges[1]?.textContent?.trim() || '';
      si.thumb   = node.querySelector('.si-thumb')?.src || '';
    }
    return normalizeSI(si);
  }
  function normalizeSI(si){
    var out={};
    out.title   = (si.title   || window.nowTitle   || window.nowPlayingTitle   || '').trim();
    out.artist  = (si.artist  || window.nowArtist  || window.nowPlayingArtist  || '').trim();
    out.album   = (si.album   || window.nowAlbum   || '').trim();
    out.year    = String(si.year|| window.nowYear  || '').trim();
    out.genre   = (si.genre   || window.nowGenre   || '').trim();
    out.label   = (si.label   || window.nowLabel   || '').trim();
    out.country = (si.country || window.nowCountry || '').trim();
    out.trackNumber = si.trackNumber || window.nowTrackNo || null;
    out.trackCount  = si.trackCount  || window.nowTrackCount || null;
    out.bpm     = si.bpm || window.nowBPM || null;
    out.key     = si.key || window.nowKey || '';
    out.thumb   = si.thumb || '';
    // duration
    out.durationSec = null;
    try { if (typeof window.songDurationSec==='number') out.durationSec = Math.floor(window.songDurationSec); } catch(_){}
    try { if (typeof window.songDurationMs==='number') out.durationSec = Math.floor(window.songDurationMs/1000); } catch(_){}
    try { if (typeof window.totalMs==='number') out.durationSec = Math.floor(window.totalMs/1000); } catch(_){}
    // last resort via MIDIFile
    if (out.durationSec==null) try{
      var ab=window.lastMIDIBuf; if (ab && ab.byteLength && typeof MIDIFile==='function'){
        var mf=new MIDIFile(ab); var evs=(mf.getMidiEvents? mf.getMidiEvents(): mf.getEvents()); var max=0; for (var i=0;i<evs.length;i++){ var e=evs[i]||{}; var pt=(e.playTime!=null? e.playTime: e.playtime!=null? e.playtime: null); if (pt!=null){ var s=Math.floor(pt/1000); if (s>max) max=s; } } out.durationSec = max||null;
      }
    }catch(_){}
    return out;
  }

  // ---------- Build info lines ----------
  function buildInfoLines(){ var si=getSongInfo(); var lines=[];
    if (si.artist || si.title) lines.push([si.title, si.artist].filter(Boolean).join(' — '));
    if (si.album)               lines.push('Album: '+si.album);
    if (si.year)                lines.push('Year: '+si.year);
    if (si.label)               lines.push('Label: '+si.label);
    if (si.country)             lines.push('Country: '+si.country);
    if (si.genre)               lines.push('Genre: '+si.genre);
    if (si.trackNumber && si.trackCount) lines.push('Track '+si.trackNumber+' of '+si.trackCount);
    else if (si.trackNumber)            lines.push('Track '+si.trackNumber);
    if (si.bpm)                 lines.push('Tempo: '+si.bpm+' BPM');
    if (si.key)                 lines.push('Key: '+si.key);
    if (si.durationSec!=null)   lines.push('Duration: '+fmtDur(si.durationSec));
    return lines.length? lines : ['Now Playing'];
  }

  // ---------- Build queue lines (optional) ----------
  function buildQueueLines(){ if (!CFG.playlist) return []; var root=$(CFG.playlist); if (!root) return []; var rows=[].slice.call(root.querySelectorAll(CFG.rowSelector)); if (!rows.length) return [];
    var currentIdx = rows.findIndex(function(r){ try{ return r.matches(CFG.currentSelector); }catch(_){ return false; } });
    var start = currentIdx>=0 ? currentIdx+1 : 0; var end = Math.min(rows.length, start+CFG.maxQueue); var out=[];
    for (var i=start;i<end;i++){ var r=rows[i]; var ti=text($in(r, CFG.titleField)); var ar=text($in(r, CFG.artistField)); var s=(ti?ti:'') + (ar?(' — '+ar):''); if (s) out.push('Next: '+s); }
    return out;
  }

  // ---------- Rotator ----------
  function rebuild(){ var info = buildInfoLines(); var queue = buildQueueLines(); var merged=[]; var a=Math.max(info.length, queue.length); for (var k=0;k<a;k++){ if (info[k]) merged.push(info[k]); if (queue[k]) merged.push(queue[k]); } if (!merged.length) merged=['Ready.']; ST.list=merged; ST.i=0; }
  function step(){ var host=ensureHost(); if (!host) return; if (!ST.list.length) rebuild(); host.textContent = ST.list[ST.i % ST.list.length]; requestAnimationFrame(function(){ host.style.opacity='1'; }); ST.i++; clearTimeout(ST.timer); ST.timer=setTimeout(step, Math.max(1500, CFG.intervalMs|0)); }
  function restart(){ clearTimeout(ST.timer); ST.timer=0; rebuild(); step(); }

  // ---------- API ----------
  window.AltTickerAllInfo = {
    init: function(opts){ opts=opts||{}; Object.keys(opts).forEach(function(k){ if (k in CFG) CFG[k]=opts[k]; }); return this; },
    start: function(){ restart(); return this; },
    stop: function(){ clearTimeout(ST.timer); ST.timer=0; if (ST.host) ST.host.style.opacity='0'; return this; },
    setContainer: function(sel){ CFG.container=sel; return this; },
    setPlaylist: function(sel,rowSel,currentSel,titleSel,artistSel){ CFG.playlist=sel; if (rowSel) CFG.rowSelector=rowSel; if (currentSel) CFG.currentSelector=currentSel; if (titleSel) CFG.titleField=titleSel; if (artistSel) CFG.artistField=artistSel; return this; },
    setInterval: function(ms){ CFG.intervalMs=Math.max(1500, parseInt(ms,10)||6000); return this; },
    setMaxQueue: function(n){ CFG.maxQueue=Math.max(1, parseInt(n,10)||5); return this; },
    rebuild: rebuild,
    restart: restart
  };

  // auto-start if included without manual init
  if (document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', function(){ rebuild(); step(); }); }
  else { rebuild(); step(); }

})(window, document);

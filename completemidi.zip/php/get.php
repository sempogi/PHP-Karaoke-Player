<?php
// Streams a file safely with no-store headers. Usage: get.php?type=sf2|midi&path=...&rid=...
@ini_set('zlib.output_compression','0');
@ini_set('output_buffering','off');

$type = isset($_GET['type']) ? $_GET['type'] : '';
$path = isset($_GET['path']) ? $_GET['path'] : '';
if ($type === '' || $path === '') { http_response_code(400); exit; }

$allowed = ($type === 'midi') ? 'midi/' : 'soundfonts/';
$full = realpath(__DIR__ . '/../' . $path);
$base = realpath(__DIR__ . '/../' . $allowed);
if ($full === false || $base === false || strpos($full, $base) !== 0) { http_response_code(404); exit; }

$mime = 'application/octet-stream';
$ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
if (in_array($ext, array('mid','midi','kar'))) $mime = 'audio/midi';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($full));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

readfile($full);
